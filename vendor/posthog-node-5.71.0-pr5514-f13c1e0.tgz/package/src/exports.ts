export * from './extensions/sentry-integration'
export * from './extensions/express'
export * from './extensions/fetch-request'
export * from './types'
export { enrichCurrentSpan } from './extensions/context/listeners'

export { FeatureFlagEvaluations } from './feature-flag-evaluations'
export { EmailError } from './emails/errors'
export type { EmailErrorName } from './emails/errors'
export type {
  CodeEmailForm,
  EmailAttachment,
  EmailDeliveryStatus,
  EmailPreferences,
  EmailReactElement,
  Emails,
  EmailStatus,
  EmailTracking,
  EmailWarning,
  GetEmailResponse,
  SendCodeEmailOptions,
  SendEmailBase,
  SendEmailOptions,
  SendEmailResponse,
  SendEmailResult,
  SendTemplateEmailOptions,
  SetEmailPreferencesOptions,
  SetEmailPreferencesResponse,
  TemplateEmailForm,
} from './emails/types'
export type {
  FlagDefinitionCacheData,
  FlagDefinitionCacheInput,
  FlagDefinitionCacheProvider,
} from './extensions/feature-flags/cache'

// Re-export FeatureFlagError from core for backwards compatibility.
// These were originally defined in posthog-node and moved to core for reuse across SDKs.
export { FeatureFlagError } from '@posthog/core'
export type { FeatureFlagErrorType, UnresolvedFlagReason } from '@posthog/core'

// Metrics types re-exported so consumers can name the `metrics` client option
// and API surface without a direct @posthog/core dependency.
export type { CaptureMetricOptions, HistogramOptions, Metrics, MetricsConfig } from '@posthog/core'

// Tracing types re-exported so consumers can name the `traces` client option and
// the span API without a direct @posthog/core dependency.
export type {
  Span,
  SpanAttributes,
  SpanAttributeValue,
  SpanKind,
  SpanStatusCode,
  SpanTimeInput,
  StartSpanOptions,
  SpanRecord,
  BeforeSpanSendFn,
  TracesConfig,
} from '@posthog/core'

// Identity helpers re-exported from core for posthog-node consumers managing
// distinct_id outside the browser SDK (e.g. Lambda functions handing out
// `download-app` redirects). Closes #2143.
export {
  cookieStateToProperties,
  cookieStoreFromHeader,
  getPostHogCookieName,
  parsePostHogCookie,
  readPostHogCookie,
  serializePostHogCookie,
  uuidv7,
} from '@posthog/core'
export type { CookieStore, PostHogCookieState } from '@posthog/core'
