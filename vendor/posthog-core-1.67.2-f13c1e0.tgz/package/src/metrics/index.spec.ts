import type { Logger } from '../types'
import { PostHogMetrics } from './index'
import type { OtlpMetric, OtlpMetricsPayload, ResolvedPostHogMetricsConfig, SendMetricsBatchOutcome } from './types'

const DEFAULT_FLUSH_INTERVAL_MS = 10000
const DEFAULT_MAX_SERIES_PER_FLUSH = 1000

const resolveForTest = (partial?: Partial<ResolvedPostHogMetricsConfig>): ResolvedPostHogMetricsConfig => ({
  ...partial,
  flushIntervalMs: partial?.flushIntervalMs ?? DEFAULT_FLUSH_INTERVAL_MS,
  maxSeriesPerFlush: partial?.maxSeriesPerFlush ?? DEFAULT_MAX_SERIES_PER_FLUSH,
})

const createMockInstance = (overrides: Record<string, any> = {}): any => ({
  isDisabled: false,
  optedOut: false,
  getLibraryId: vi.fn(() => 'posthog-core-tests'),
  getLibraryVersion: vi.fn(() => '0.0.0-test'),
  _sendMetricsBatch: vi.fn((): Promise<SendMetricsBatchOutcome> => Promise.resolve({ kind: 'ok' })),
  ...overrides,
})

const createMockLogger = (): Logger => {
  const logger: any = {
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    critical: vi.fn(),
  }
  logger.createLogger = vi.fn(() => logger)
  return logger as Logger
}

describe('PostHogMetrics', () => {
  let mockInstance: any
  let logger: Logger

  const createMetrics = (config?: Partial<ResolvedPostHogMetricsConfig>, instance?: any): PostHogMetrics => {
    return new PostHogMetrics(instance ?? mockInstance, resolveForTest(config), logger)
  }

  const sentPayloads = (instance?: any): OtlpMetricsPayload[] =>
    (instance ?? mockInstance)._sendMetricsBatch.mock.calls.map((c: any[]) => c[0])

  const sentMetrics = (instance?: any): OtlpMetric[] =>
    sentPayloads(instance).flatMap((p) => p.resourceMetrics[0].scopeMetrics[0].metrics)

  beforeEach(() => {
    vi.useFakeTimers()
    mockInstance = createMockInstance()
    logger = createMockLogger()
    // Retry delays carry jitter; pinned to its midpoint so every timing
    // assertion here measures the backoff itself and cannot flake.
    vi.spyOn(Math, 'random').mockReturnValue(0.5)
  })

  afterEach(() => {
    vi.useRealTimers()
  })

  describe('flushCoalesced', () => {
    it('keeps at most one send in flight and one queued behind it, and sends every sample', async () => {
      let resolveSend!: (o: SendMetricsBatchOutcome) => void
      mockInstance._sendMetricsBatch
        .mockImplementationOnce(() => new Promise<SendMetricsBatchOutcome>((r) => (resolveSend = r)))
        .mockResolvedValue({ kind: 'ok' })
      const metrics = createMetrics()

      metrics.count('requests', 1)
      const first = metrics.flushCoalesced()
      await Promise.resolve()
      await Promise.resolve()
      expect(mockInstance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      // Many requests finish while the first send is in flight: they share one queued flush.
      const queued = [1, 2, 3, 4, 5].map(() => {
        metrics.count('requests', 1)
        return metrics.flushCoalesced()
      })
      expect(new Set(queued).size).toBe(1)

      resolveSend({ kind: 'ok' })
      await Promise.all([first, ...queued])
      expect(mockInstance._sendMetricsBatch).toHaveBeenCalledTimes(2)
      expect(sentMetrics().reduce((sum, m) => sum + m.sum!.dataPoints[0].asDouble!, 0)).toBe(6)
    })

    it('does not start a queued flush when the send it waited behind starts a backoff', async () => {
      let resolveSend!: (o: SendMetricsBatchOutcome) => void
      mockInstance._sendMetricsBatch
        .mockImplementationOnce(() => new Promise<SendMetricsBatchOutcome>((r) => (resolveSend = r)))
        .mockResolvedValue({ kind: 'ok' })
      const metrics = createMetrics()

      metrics.count('requests', 1)
      const first = metrics.flushCoalesced()
      await Promise.resolve()
      await Promise.resolve()
      metrics.count('requests', 1)
      const queued = metrics.flushCoalesced()

      resolveSend({ kind: 'retry-later', error: new Error('429'), retryAfterMs: 300_000 })
      await Promise.all([first, queued])
      expect(mockInstance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      // The retry timer delivers the retained samples once the backoff ends.
      await vi.advanceTimersByTimeAsync(300_000)
      expect(mockInstance._sendMetricsBatch).toHaveBeenCalledTimes(2)
      const retried = sentPayloads()[1].resourceMetrics[0].scopeMetrics[0].metrics
      expect(retried[0].sum!.dataPoints[0].asDouble).toBe(2)
    })

    it('does not send while a failed send is backing off', async () => {
      mockInstance._sendMetricsBatch.mockResolvedValueOnce({
        kind: 'retry-later',
        error: new Error('429'),
        retryAfterMs: 300_000,
      })
      const metrics = createMetrics()
      metrics.count('requests', 1)
      await metrics.flushCoalesced()
      expect(mockInstance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      metrics.count('requests', 1)
      await metrics.flushCoalesced()
      await metrics.flushCoalesced()
      expect(mockInstance._sendMetricsBatch).toHaveBeenCalledTimes(1)
    })
  })

  describe('aggregation semantics', () => {
    it('sums count samples for the same series into one delta data point', async () => {
      const metrics = createMetrics()
      metrics.count('orders_created', 1)
      metrics.count('orders_created', 1)
      metrics.count('orders_created', 3)
      await metrics.flush()

      const sent = sentMetrics()
      expect(sent).toHaveLength(1)
      expect(sent[0].name).toBe('orders_created')
      expect(sent[0].sum).toMatchObject({ aggregationTemporality: 1, isMonotonic: true })
      expect(sent[0].sum!.dataPoints).toHaveLength(1)
      expect(sent[0].sum!.dataPoints[0].asDouble).toBe(5)
    })

    it('defaults count value to 1', async () => {
      const metrics = createMetrics()
      metrics.count('clicks')
      metrics.count('clicks')
      await metrics.flush()

      expect(sentMetrics()[0].sum!.dataPoints[0].asDouble).toBe(2)
    })

    it('keeps only the last gauge value per series per window', async () => {
      const metrics = createMetrics()
      metrics.gauge('active_connections', 42)
      metrics.gauge('active_connections', 17)
      await metrics.flush()

      const sent = sentMetrics()
      expect(sent).toHaveLength(1)
      expect(sent[0].gauge!.dataPoints).toHaveLength(1)
      expect(sent[0].gauge!.dataPoints[0].asDouble).toBe(17)
    })

    it('accumulates histogram observations into count/sum/min/max and buckets', async () => {
      const metrics = createMetrics()
      metrics.histogram('api_latency', 10, { unit: 'ms' })
      metrics.histogram('api_latency', 20, { unit: 'ms' })
      metrics.histogram('api_latency', 30, { unit: 'ms' })
      await metrics.flush()

      const sent = sentMetrics()
      expect(sent).toHaveLength(1)
      expect(sent[0].unit).toBe('ms')
      const dp = sent[0].histogram!.dataPoints[0]
      expect(dp.count).toBe(3)
      expect(dp.sum).toBe(60)
      expect(dp.min).toBe(10)
      expect(dp.max).toBe(30)
      expect(dp.explicitBounds.length).toBeGreaterThan(0)
      expect(dp.bucketCounts).toHaveLength(dp.explicitBounds.length + 1)
      expect(dp.bucketCounts.reduce((a, b) => a + b, 0)).toBe(3)
      expect(sent[0].histogram!.aggregationTemporality).toBe(1)
    })

    it('places histogram observations in the correct buckets', async () => {
      const metrics = createMetrics()
      // Default OTel bounds start [0, 5, 10, 25, ...]: -1 → bucket 0 (≤0),
      // 3 → bucket 1 (≤5), 10 → bucket 2 (≤10), 1e9 → overflow bucket.
      metrics.histogram('x', -1)
      metrics.histogram('x', 3)
      metrics.histogram('x', 10)
      metrics.histogram('x', 1e9)
      await metrics.flush()

      const dp = sentMetrics()[0].histogram!.dataPoints[0]
      expect(dp.bucketCounts[0]).toBe(1)
      expect(dp.bucketCounts[1]).toBe(1)
      expect(dp.bucketCounts[2]).toBe(1)
      expect(dp.bucketCounts[dp.bucketCounts.length - 1]).toBe(1)
    })

    it('splits series by attribute values but merges identical attribute sets regardless of key order', async () => {
      const metrics = createMetrics()
      metrics.count('api_calls', 1, { attributes: { route: '/home', plan: 'free' } })
      metrics.count('api_calls', 1, { attributes: { plan: 'free', route: '/home' } })
      metrics.count('api_calls', 1, { attributes: { route: '/checkout', plan: 'free' } })
      await metrics.flush()

      const sent = sentMetrics()
      expect(sent).toHaveLength(1)
      expect(sent[0].sum!.dataPoints).toHaveLength(2)
      const values = sent[0].sum!.dataPoints.map((dp) => dp.asDouble).sort()
      expect(values).toEqual([1, 2])
    })

    it('emits separate metric entries for the same name with different types or units', async () => {
      const metrics = createMetrics()
      metrics.count('throughput', 1)
      metrics.gauge('throughput', 5)
      metrics.histogram('size', 1, { unit: 'byte' })
      metrics.histogram('size', 1, { unit: 'kilobyte' })
      await metrics.flush()

      const sent = sentMetrics()
      expect(sent).toHaveLength(4)
      const throughput = sent.filter((m) => m.name === 'throughput')
      expect(throughput.some((m) => m.sum)).toBe(true)
      expect(throughput.some((m) => m.gauge)).toBe(true)
      const sizes = sent.filter((m) => m.name === 'size')
      expect(sizes.map((m) => m.unit).sort()).toEqual(['byte', 'kilobyte'])
    })

    it('encodes attributes as OTLP key-value pairs on the data point', async () => {
      const metrics = createMetrics()
      metrics.count('api_calls', 1, { attributes: { route: '/home', retries: 2, cached: true } })
      await metrics.flush()

      const attrs = sentMetrics()[0].sum!.dataPoints[0].attributes
      expect(attrs).toContainEqual({ key: 'route', value: { stringValue: '/home' } })
      expect(attrs).toContainEqual({ key: 'retries', value: { intValue: '2' } })
      expect(attrs).toContainEqual({ key: 'cached', value: { boolValue: true } })
    })

    // The encoder is shared with logs, so the debug line it emits on the
    // out-of-range path only reaches anyone if metrics passes its logger down.
    it('encodes an out-of-int64 attribute as a string and reports it through the logger', async () => {
      const metrics = createMetrics()
      metrics.count('api_calls', 1, { attributes: { huge: 2 ** 63 } as any })
      await metrics.flush()

      const attrs = sentMetrics()[0].sum!.dataPoints[0].attributes
      expect(attrs).toContainEqual({ key: 'huge', value: { stringValue: '9223372036854775808' } })
      expect((logger.debug as vi.Mock).mock.calls.some((c) => String(c[0]).includes('outside the int64 range'))).toBe(
        true
      )
    })

    it('stamps delta data points with a window: startTimeUnixNano <= timeUnixNano, both nano strings', async () => {
      const metrics = createMetrics()
      metrics.count('orders_created', 1)
      vi.advanceTimersByTime(2000)
      await metrics.flush()

      const dp = sentMetrics()[0].sum!.dataPoints[0]
      expect(dp.timeUnixNano).toMatch(/^\d+$/)
      expect(dp.startTimeUnixNano).toMatch(/^\d+$/)
      expect(BigInt(dp.startTimeUnixNano!)).toBeLessThanOrEqual(BigInt(dp.timeUnixNano))
    })
  })

  describe('histogram bounds', () => {
    const DEFAULT_BOUNDS = [0, 5, 10, 25, 50, 75, 100, 250, 500, 750, 1000, 2500, 5000, 7500, 10000]
    const histogramPoints = (name: string) =>
      sentMetrics()
        .filter((m) => m.name === name)
        .flatMap((m) => m.histogram!.dataPoints)
    const warnings = () => (logger.warn as vi.Mock).mock.calls.map((c) => String(c[0]))

    it('uses the OpenTelemetry default bounds when none are passed', async () => {
      const metrics = createMetrics()
      metrics.histogram('h', 1)
      await metrics.flush()

      expect(histogramPoints('h')[0].explicitBounds).toEqual(DEFAULT_BOUNDS)
    })

    it('buckets values with the bounds the caller passes', async () => {
      const metrics = createMetrics()
      // (-inf, 100] ← 50 and 100, (100, 200] ← 150, overflow ← 201.
      for (const v of [50, 100, 150, 201]) {
        metrics.histogram('h', v, { bounds: [100, 200] })
      }
      await metrics.flush()

      const dp = histogramPoints('h')[0]
      expect(dp.explicitBounds).toEqual([100, 200])
      expect(dp.bucketCounts).toEqual([2, 1, 1])
      expect(dp.min).toBe(50)
      expect(dp.max).toBe(201)
    })

    it('copies the bounds so a caller mutating its array cannot change the buckets', async () => {
      const metrics = createMetrics()
      const bounds = [100, 200]
      metrics.histogram('h', 150, { bounds })
      bounds[0] = 175
      metrics.histogram('h', 150, { bounds: [100, 200] })
      await metrics.flush()

      const dp = histogramPoints('h')[0]
      expect(dp.explicitBounds).toEqual([100, 200])
      expect(dp.bucketCounts).toEqual([0, 2, 0])
      // The second call passes equal bounds in a new array, which is not a conflict.
      expect(logger.warn).not.toHaveBeenCalled()
    })

    it('records a sample with conflicting bounds in the first bounds and warns once', async () => {
      const metrics = createMetrics()
      metrics.histogram('h', 150, { bounds: [100, 200] })
      metrics.histogram('h', 150, { bounds: [10, 20, 30] })
      metrics.histogram('h', 150, { bounds: [10, 20, 30] })
      metrics.histogram('h', 150)
      await metrics.flush()

      const dp = histogramPoints('h')[0]
      expect(dp.explicitBounds).toEqual([100, 200])
      expect(dp.bucketCounts).toEqual([0, 4, 0])
      expect(warnings().filter((w) => w.includes("Histogram 'h' already uses the bounds"))).toHaveLength(1)
    })

    it('treats omitted bounds as the default when checking for a conflict', async () => {
      const metrics = createMetrics()
      metrics.histogram('h', 1)
      metrics.histogram('h', 1, { bounds: [100, 200] })
      await metrics.flush()

      expect(histogramPoints('h')[0].explicitBounds).toHaveLength(15)
      expect(warnings().some((w) => w.includes("Histogram 'h' already uses the bounds"))).toBe(true)
    })

    it('fixes the bounds per histogram across attribute series', async () => {
      const metrics = createMetrics()
      metrics.histogram('h', 150, { bounds: [100, 200], attributes: { route: 'a' } })
      metrics.histogram('h', 150, { bounds: [10, 20], attributes: { route: 'b' } })
      await metrics.flush()

      const points = histogramPoints('h')
      expect(points).toHaveLength(2)
      expect(points.map((dp) => dp.explicitBounds)).toEqual([
        [100, 200],
        [100, 200],
      ])
    })

    it('keeps the bounds of a histogram separate per unit', async () => {
      const metrics = createMetrics()
      metrics.histogram('h', 1, { unit: 'ms', bounds: [100, 200] })
      metrics.histogram('h', 1, { unit: 's', bounds: [1, 2, 3] })
      await metrics.flush()

      const byUnit = Object.fromEntries(sentMetrics().map((m) => [m.unit, m.histogram!.dataPoints[0].explicitBounds]))
      expect(byUnit).toEqual({ ms: [100, 200], s: [1, 2, 3] })
      expect(logger.warn).not.toHaveBeenCalled()
    })

    it('keeps the first bounds across flush windows and warns on a conflict once per window', async () => {
      const metrics = createMetrics()
      metrics.histogram('h', 150, { bounds: [100, 200] })
      metrics.histogram('h', 150, { bounds: [10, 20] })
      await metrics.flush()
      metrics.histogram('h', 150, { bounds: [10, 20] })
      await metrics.flush()

      expect(histogramPoints('h').map((dp) => dp.explicitBounds)).toEqual([
        [100, 200],
        [100, 200],
      ])
      expect(warnings().filter((w) => w.includes("Histogram 'h' already uses the bounds"))).toHaveLength(2)
    })

    it('merges a failed window back into a live window with the same bounds', async () => {
      mockInstance._sendMetricsBatch
        .mockResolvedValueOnce({ kind: 'retry-later', error: new Error('offline') })
        .mockResolvedValue({ kind: 'ok' })
      const metrics = createMetrics()
      metrics.histogram('h', 50, { bounds: [100, 200] })
      await metrics.flush()
      metrics.histogram('h', 150, { bounds: [10, 20] })
      await metrics.flush()

      const dp = histogramPoints('h')[1]
      expect(dp.explicitBounds).toEqual([100, 200])
      expect(dp.bucketCounts).toEqual([1, 1, 0])
      expect(dp.count).toBe(2)
      expect(dp.sum).toBe(200)
      expect(dp.min).toBe(50)
      expect(dp.max).toBe(150)
    })

    it('lets reset() clear the bounds so the next sample sets them again', async () => {
      const metrics = createMetrics()
      metrics.histogram('h', 150, { bounds: [100, 200] })
      metrics.reset()
      metrics.histogram('h', 15, { bounds: [10, 20] })
      await metrics.flush()

      expect(histogramPoints('h').map((dp) => dp.explicitBounds)).toEqual([[10, 20]])
      expect(logger.warn).not.toHaveBeenCalled()
    })

    it.each([
      ['empty', []],
      ['not an array', 'nope'],
      ['not increasing', [100, 100]],
      ['decreasing', [200, 100]],
      ['non-finite', [100, Infinity]],
      ['NaN', [NaN]],
      ['non-number', [100, '200']],
    ])('drops a sample whose bounds are %s', async (_name, bounds) => {
      const metrics = createMetrics()
      metrics.histogram('h', 1, { bounds: bounds as any })
      await metrics.flush()

      expect(sentMetrics()).toHaveLength(0)
      expect(warnings().some((w) => w.includes("Dropping histogram 'h': bounds must be"))).toBe(true)
    })

    it('does not fix the bounds from a sample with invalid bounds', async () => {
      const metrics = createMetrics()
      metrics.histogram('h', 1, { bounds: [200, 100] })
      metrics.histogram('h', 150, { bounds: [100, 200] })
      await metrics.flush()

      expect(histogramPoints('h')[0].explicitBounds).toEqual([100, 200])
    })

    it('drops new histograms that pass custom bounds past the bounds limit, and warns once', async () => {
      const metrics = createMetrics({ maxSeriesPerFlush: 2 })
      metrics.histogram('a', 1)
      metrics.histogram('b', 1)
      await metrics.flush()
      metrics.histogram('c', 15, { bounds: [10, 20] })
      metrics.histogram('d', 1)
      await metrics.flush()
      metrics.histogram('c', 150, { bounds: [100, 200] })
      metrics.histogram('d', 1, { bounds: [...DEFAULT_BOUNDS] })
      await metrics.flush()

      expect(sentMetrics().map((m) => m.name)).toEqual(['a', 'b', 'd', 'd'])
      expect(histogramPoints('d').map((dp) => dp.explicitBounds)).toEqual([DEFAULT_BOUNDS, DEFAULT_BOUNDS])
      expect(warnings().filter((w) => w.includes('Histogram bounds limit reached'))).toHaveLength(1)
    })

    it('never sends one histogram with different bounds from two clients when only one is past the bounds limit', async () => {
      const instanceA = createMockInstance()
      const instanceB = createMockInstance()
      const clientA = createMetrics({ maxSeriesPerFlush: 1 }, instanceA)
      const clientB = createMetrics({ maxSeriesPerFlush: 1 }, instanceB)

      clientA.histogram('h', 150, { bounds: [100, 200] })
      await clientA.flush()
      clientB.histogram('other', 1)
      await clientB.flush()
      clientB.histogram('h', 150, { bounds: [100, 200] })
      await clientB.flush()

      const bounds = [...sentMetrics(instanceA), ...sentMetrics(instanceB)]
        .filter((m) => m.name === 'h')
        .map((m) => m.histogram!.dataPoints[0].explicitBounds)
      expect(bounds).toEqual([[100, 200]])
    })

    it('merges a failed window of a histogram past the bounds limit into the live window', async () => {
      let traceparent: string | null = null
      mockInstance = createMockInstance({ getActiveSpan: () => ({ traceparent: () => traceparent }) })
      const metrics = createMetrics({ maxSeriesPerFlush: 1 })
      metrics.histogram('a', 1)
      await metrics.flush()
      let resolveSend!: (outcome: SendMetricsBatchOutcome) => void
      mockInstance._sendMetricsBatch.mockImplementationOnce(
        () => new Promise<SendMetricsBatchOutcome>((resolve) => (resolveSend = resolve))
      )

      traceparent = '00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01'
      metrics.histogram('c', 15)
      const inflight = metrics.flush()
      traceparent = null
      metrics.histogram('c', 150)
      resolveSend({ kind: 'retry-later', error: new Error('offline') })
      await inflight
      await metrics.flush()

      const dp = histogramPoints('c')[1]
      expect(dp.explicitBounds).toEqual(DEFAULT_BOUNDS)
      expect(dp.count).toBe(2)
      expect(dp.sum).toBe(165)
      // 15 falls in (10, 25] and 150 in (100, 250].
      expect(dp.bucketCounts).toEqual([0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0])
      expect(dp.min).toBe(15)
      expect(dp.max).toBe(150)
      expect(dp.exemplars?.map((e) => e.asDouble)).toEqual([15])
    })

    it('keeps the caller bounds intact when beforeSend edits them in place', async () => {
      const metrics = createMetrics({
        beforeSend: (m) => {
          m.bounds?.forEach((b, i) => (m.bounds![i] = b / 1000))
          m.value /= 1000
          m.unit = 's'
          return m
        },
      })
      const bounds = [100, 1000]
      metrics.histogram('h', 500, { unit: 'ms', bounds })
      metrics.histogram('h', 500, { unit: 'ms', bounds })
      await metrics.flush()

      expect(bounds).toEqual([100, 1000])
      const dp = histogramPoints('h')[0]
      expect(dp.explicitBounds).toEqual([0.1, 1])
      expect(dp.bucketCounts).toEqual([0, 2, 0])
      expect(logger.warn).not.toHaveBeenCalled()
    })

    it('does not fix the bounds for a sample the series cap drops', async () => {
      const metrics = createMetrics({ maxSeriesPerFlush: 1 })
      metrics.count('fills_the_window', 1)
      metrics.histogram('h', 1, { bounds: [10, 20] })
      await metrics.flush()
      metrics.histogram('h', 150, { bounds: [100, 200] })
      await metrics.flush()

      expect(histogramPoints('h').map((dp) => dp.explicitBounds)).toEqual([[100, 200]])
    })
  })

  describe('exemplars', () => {
    const TRACE_ID = '4bf92f3577b34da6a3ce929d0e0e4736'
    const SPAN_ID = '00f067aa0ba902b7'
    const withActiveSpan = (traceparent: string | null): any =>
      createMockInstance({ getActiveSpan: () => ({ traceparent: () => traceparent }) })

    const dataPoints = (instance: any): any[] =>
      sentMetrics(instance).map((m) => (m.sum ?? m.gauge ?? m.histogram)!.dataPoints[0])

    it('stamps every metric type with the last sample recorded inside a sampled span', async () => {
      const instance = withActiveSpan(`00-${TRACE_ID}-${SPAN_ID}-01`)
      const metrics = createMetrics(undefined, instance)
      metrics.count('c', 1)
      metrics.count('c', 4)
      metrics.gauge('g', 7)
      metrics.histogram('h', 12)
      await metrics.flush()

      const points = dataPoints(instance)
      expect(points.map((p) => p.exemplars)).toEqual(
        [4, 7, 12].map((value) => [
          {
            filteredAttributes: [],
            timeUnixNano: expect.stringMatching(/^\d+$/),
            asDouble: value,
            traceId: TRACE_ID,
            spanId: SPAN_ID,
          },
        ])
      )
    })

    it.each([
      ['no getActiveSpan on the host', createMockInstance],
      ['no active span', () => createMockInstance({ getActiveSpan: () => null })],
      ['an unsampled span', () => withActiveSpan(`00-${TRACE_ID}-${SPAN_ID}-00`)],
      ['a span with no traceparent', () => withActiveSpan(null)],
      [
        'a throwing host',
        () =>
          createMockInstance({
            getActiveSpan: () => {
              throw new Error('boom')
            },
          }),
      ],
    ])('records the sample without an exemplar for %s', async (_, makeInstance) => {
      const instance = makeInstance()
      const metrics = createMetrics(undefined, instance)
      metrics.count('c', 2)
      await metrics.flush()

      const [point] = dataPoints(instance)
      expect(point.asDouble).toBe(2)
      expect(point).not.toHaveProperty('exemplars')
    })

    it('keeps the exemplar of a window merged back after a failed flush', async () => {
      const instance = withActiveSpan(`00-${TRACE_ID}-${SPAN_ID}-01`)
      instance._sendMetricsBatch
        .mockResolvedValueOnce({ kind: 'retry-later', error: new Error('503') })
        .mockResolvedValue({ kind: 'ok' })
      const metrics = createMetrics(undefined, instance)
      metrics.count('c', 1)
      await metrics.flush()
      instance.getActiveSpan = () => null
      metrics.count('c', 2)
      await metrics.flush()

      const point = dataPoints(instance)[1]
      expect(point.asDouble).toBe(3)
      expect(point.exemplars[0]).toMatchObject({ traceId: TRACE_ID, spanId: SPAN_ID, asDouble: 1 })
    })
  })

  describe('resource attributes', () => {
    it('attaches service.name, sdk identity, and user resource attributes', async () => {
      const metrics = createMetrics({
        serviceName: 'checkout-web',
        environment: 'production',
        resourceAttributes: { 'k8s.pod': 'web-1' },
      })
      metrics.count('orders_created', 1)
      await metrics.flush()

      const payload = sentPayloads()[0]
      const resourceAttrs = payload.resourceMetrics[0].resource.attributes
      expect(resourceAttrs).toContainEqual({ key: 'service.name', value: { stringValue: 'checkout-web' } })
      expect(resourceAttrs).toContainEqual({ key: 'deployment.environment', value: { stringValue: 'production' } })
      expect(resourceAttrs).toContainEqual({ key: 'k8s.pod', value: { stringValue: 'web-1' } })
      expect(resourceAttrs).toContainEqual({ key: 'telemetry.sdk.name', value: { stringValue: 'posthog-core-tests' } })
      expect(payload.resourceMetrics[0].scopeMetrics[0].scope).toEqual({
        name: 'posthog-core-tests',
        version: '0.0.0-test',
      })
    })

    it('falls back to unknown_service and never lets resourceAttributes clobber service.name', async () => {
      const metrics = createMetrics({ resourceAttributes: { 'service.name': 'spoofed' } })
      metrics.count('x', 1)
      await metrics.flush()

      const resourceAttrs = sentPayloads()[0].resourceMetrics[0].resource.attributes
      expect(resourceAttrs).toContainEqual({ key: 'service.name', value: { stringValue: 'unknown_service' } })
      expect(resourceAttrs.filter((kv) => kv.key === 'service.name')).toHaveLength(1)
    })
  })

  describe('flush behavior', () => {
    it('sends nothing until the flush interval elapses, then sends the window once', async () => {
      const metrics = createMetrics({ flushIntervalMs: 5000 })
      metrics.count('orders_created', 1)
      expect(mockInstance._sendMetricsBatch).not.toHaveBeenCalled()

      await vi.advanceTimersByTimeAsync(5000)
      expect(mockInstance._sendMetricsBatch).toHaveBeenCalledTimes(1)
    })

    it('keeps flushing on the interval while captures keep arriving', async () => {
      // Every capture arms the timer, and metrics have no size trigger to fall
      // back on: re-arming a pending one would stop the window ever being sent.
      const metrics = createMetrics({ flushIntervalMs: 10_000 })

      for (let i = 0; i < 60; i++) {
        metrics.count('orders_created', 1)
        await vi.advanceTimersByTimeAsync(1000)
      }

      expect(mockInstance._sendMetricsBatch).toHaveBeenCalled()
    })

    it('waits out Retry-After even when a flush timer is already pending', async () => {
      // The capture arms a timer at the flush interval; the failed flush then asks
      // for far longer. The pending timer must not fire first.
      const instance = createMockInstance({
        _sendMetricsBatch: vi.fn((): Promise<SendMetricsBatchOutcome> =>
          Promise.resolve({ kind: 'retry-later', error: new Error('429'), retryAfterMs: 300_000 })
        ),
      })
      const metrics = createMetrics({ flushIntervalMs: 10_000 }, instance)
      metrics.count('orders_created', 1)
      await metrics.flush()
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      await vi.advanceTimersByTimeAsync(11_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      await vi.advanceTimersByTimeAsync(300_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(2)
    })

    it('clears Retry-After on an outcome that is not a retry', async () => {
      // Only a retriable outcome carries a wait. A stale one left set here would
      // pin every later flush at the server's old window forever.
      const outcomes: SendMetricsBatchOutcome[] = [
        { kind: 'retry-later', error: new Error('429'), retryAfterMs: 300_000 },
        { kind: 'fatal', error: new Error('400') },
      ]
      const instance = createMockInstance({
        _sendMetricsBatch: vi.fn(() => Promise.resolve(outcomes.shift() ?? { kind: 'ok' })),
      })
      const metrics = createMetrics({ flushIntervalMs: 10_000 }, instance)
      metrics.count('orders_created', 1)
      await metrics.flush()

      // The wait elapses, the retry lands a 400, and that ends the wait.
      await vi.advanceTimersByTimeAsync(300_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(2)

      metrics.count('orders_created', 1)
      await vi.advanceTimersByTimeAsync(10_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(3)
    })

    it('keeps the Retry-After window when a batch is refused for size', async () => {
      // `too-large` is a verdict on the body's size — the SDK's own or a 413 —
      // so it says nothing about the endpoint's rate limit. Ending the wait on
      // it lets the next refusal install a fresh window, pushing the retry out
      // past the deadline the endpoint actually named — observed here as the
      // flush landing at 300s rather than at 310s.
      const outcomes: SendMetricsBatchOutcome[] = [
        { kind: 'retry-later', error: new Error('429'), retryAfterMs: 300_000 },
        { kind: 'too-large' },
        { kind: 'retry-later', error: new Error('429'), retryAfterMs: 300_000 },
      ]
      const instance = createMockInstance({
        _sendMetricsBatch: vi.fn(() => Promise.resolve(outcomes.shift() ?? { kind: 'ok' })),
      })
      const metrics = createMetrics({ flushIntervalMs: 1000 }, instance)
      metrics.count('orders_created', 1)
      await metrics.flush()
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      await vi.advanceTimersByTimeAsync(10_000)
      await metrics.flush()
      metrics.count('orders_created', 1)
      await metrics.flush()
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(3)

      await vi.advanceTimersByTimeAsync(295_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(4)
    })

    it('closes the window at the ceiling for a host out-pacing it', async () => {
      // Each refusal sliding the deadline would keep `_nextFlushDelay` pinned at
      // the full window, so the flush cadence would never recover.
      const instance = createMockInstance({
        _sendMetricsBatch: vi.fn((): Promise<SendMetricsBatchOutcome> =>
          Promise.resolve({ kind: 'retry-later', error: new Error('429'), retryAfterMs: 30_000 })
        ),
      })
      const metrics = createMetrics({ flushIntervalMs: 60_000 }, instance)
      metrics.count('orders_created', 1)
      await metrics.flush()
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      // Sampled: whether a given moment falls inside a window is timing
      // dependent, but it must fall outside one sometimes.
      let sawWindowClosed = false
      for (let i = 0; i < 70; i++) {
        await vi.advanceTimersByTimeAsync(5000)
        // Sampled before the flush: a flush that finds the window closed opens
        // a fresh one, so sampling after it would always look open.
        if ((metrics as any)._retryAfter.remainingMs() === 0) {
          sawWindowClosed = true
        }
        metrics.count('orders_created', 1)
        await metrics.flush()
      }
      expect(sawWindowClosed).toBe(true)
    })

    it('does not install a Retry-After that lands after reset', async () => {
      let settle: ((outcome: SendMetricsBatchOutcome) => void) | undefined
      const instance = createMockInstance({
        _sendMetricsBatch: vi.fn(
          (): Promise<SendMetricsBatchOutcome> =>
            new Promise((resolve) => {
              settle = resolve
            })
        ),
      })
      const metrics = createMetrics({ flushIntervalMs: 1000 }, instance)
      metrics.count('orders_created', 1)
      await vi.advanceTimersByTimeAsync(1000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      metrics.reset()

      // Settle first: the capture that arms the next timer must not find a
      // window belonging to the client that was just torn down.
      settle?.({ kind: 'retry-later', error: new Error('429'), retryAfterMs: 300_000 })
      await vi.advanceTimersByTimeAsync(0)

      metrics.count('orders_created', 1)
      await vi.advanceTimersByTimeAsync(1000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(2)
    })

    it('drops a Retry-After wait on reset', async () => {
      const instance = createMockInstance({
        _sendMetricsBatch: vi.fn((): Promise<SendMetricsBatchOutcome> =>
          Promise.resolve({ kind: 'retry-later', error: new Error('429'), retryAfterMs: 300_000 })
        ),
      })
      const metrics = createMetrics({ flushIntervalMs: 10_000 }, instance)
      metrics.count('orders_created', 1)
      await metrics.flush()

      metrics.reset()
      metrics.count('orders_created', 1)
      await vi.advanceTimersByTimeAsync(10_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(2)
    })

    it('does not restart a served-out wait for a sample captured mid-retry', async () => {
      // A deadline, not a duration. The retry's timer has already fired, so the
      // capture below is the one that arms the next timer — and it sees the
      // wait still set, because the send it belongs to has not settled. Holding
      // a duration here re-arms for the whole window a second time and leaves
      // the sample 300s behind on an endpoint that has already recovered.
      let settleRetry: ((outcome: SendMetricsBatchOutcome) => void) | undefined
      let call = 0
      const instance = createMockInstance({
        _sendMetricsBatch: vi.fn((): Promise<SendMetricsBatchOutcome> => {
          call++
          if (call === 1) {
            return Promise.resolve({ kind: 'retry-later', error: new Error('429'), retryAfterMs: 300_000 })
          }
          return new Promise<SendMetricsBatchOutcome>((resolve) => {
            settleRetry = resolve
          })
        }),
      })
      const metrics = createMetrics({ flushIntervalMs: 10_000 }, instance)
      metrics.count('orders_created', 1)
      await vi.advanceTimersByTimeAsync(10_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      // The wait elapses and the retry goes out, but hangs.
      await vi.advanceTimersByTimeAsync(300_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(2)

      metrics.count('orders_created', 1)
      settleRetry?.({ kind: 'ok' })
      await vi.advanceTimersByTimeAsync(0)

      // One interval, not another window.
      await vi.advanceTimersByTimeAsync(10_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(3)
    })

    it('keeps its own interval when the endpoint asks for less', async () => {
      const instance = createMockInstance({
        _sendMetricsBatch: vi.fn((): Promise<SendMetricsBatchOutcome> =>
          Promise.resolve({ kind: 'retry-later', error: new Error('503'), retryAfterMs: 10 })
        ),
      })
      const metrics = createMetrics({ flushIntervalMs: 10_000 }, instance)
      metrics.count('orders_created', 1)
      await vi.advanceTimersByTimeAsync(10_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      await vi.advanceTimersByTimeAsync(1000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      await vi.advanceTimersByTimeAsync(10_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(2)
    })

    it('sends on an explicit flush inside the window', async () => {
      // Lifecycle drains (RN background, shutdown) must not become no-ops for
      // the length of a window; metrics has no `force` escape hatch.
      const outcomes: SendMetricsBatchOutcome[] = [
        { kind: 'retry-later', error: new Error('429'), retryAfterMs: 300_000 },
      ]
      const instance = createMockInstance({
        _sendMetricsBatch: vi.fn((): Promise<SendMetricsBatchOutcome> =>
          Promise.resolve(outcomes.shift() ?? { kind: 'ok' })
        ),
      })
      const metrics = createMetrics({ flushIntervalMs: 10_000 }, instance)
      metrics.count('orders_created', 1)
      await vi.advanceTimersByTimeAsync(10_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      metrics.count('orders_created', 1)
      await metrics.flush()
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(2)
    })

    it('ends the wait when a later failure names none', async () => {
      const outcomes: SendMetricsBatchOutcome[] = [
        { kind: 'retry-later', error: new Error('429'), retryAfterMs: 300_000 },
        { kind: 'retry-later', error: new Error('503') },
      ]
      const instance = createMockInstance({
        _sendMetricsBatch: vi.fn((): Promise<SendMetricsBatchOutcome> =>
          Promise.resolve(outcomes.shift() ?? { kind: 'ok' })
        ),
      })
      const metrics = createMetrics({ flushIntervalMs: 10_000 }, instance)
      metrics.count('orders_created', 1)
      await vi.advanceTimersByTimeAsync(10_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      await vi.advanceTimersByTimeAsync(300_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(2)

      // Off the 300s window and back on our own backoff: two consecutive
      // failures, so one doubling of the interval rather than another 300s.
      await vi.advanceTimersByTimeAsync(20_000)
      expect(instance._sendMetricsBatch).toHaveBeenCalledTimes(3)
    })

    it('does not send when the window is empty', async () => {
      createMetrics({ flushIntervalMs: 5000 })
      await vi.advanceTimersByTimeAsync(15000)
      expect(mockInstance._sendMetricsBatch).not.toHaveBeenCalled()

      const metrics = createMetrics()
      await metrics.flush()
      expect(mockInstance._sendMetricsBatch).not.toHaveBeenCalled()
    })

    it('resets the window after a successful flush — values do not leak into the next one', async () => {
      const metrics = createMetrics()
      metrics.count('orders_created', 5)
      await metrics.flush()
      metrics.count('orders_created', 2)
      await metrics.flush()

      const payloads = sentPayloads()
      expect(payloads).toHaveLength(2)
      expect(payloads[1].resourceMetrics[0].scopeMetrics[0].metrics[0].sum!.dataPoints[0].asDouble).toBe(2)
    })

    it('retains the window and merges with new samples when the send says retry-later', async () => {
      mockInstance._sendMetricsBatch
        .mockResolvedValueOnce({ kind: 'retry-later', error: new Error('offline') })
        .mockResolvedValue({ kind: 'ok' })

      const metrics = createMetrics()
      metrics.count('orders_created', 5)
      await metrics.flush()
      metrics.count('orders_created', 2)
      await metrics.flush()

      const payloads = sentPayloads()
      expect(payloads).toHaveLength(2)
      expect(payloads[1].resourceMetrics[0].scopeMetrics[0].metrics[0].sum!.dataPoints[0].asDouble).toBe(7)
    })

    it('drops the window on a fatal send outcome', async () => {
      mockInstance._sendMetricsBatch
        .mockResolvedValueOnce({ kind: 'fatal', error: new Error('bad key') })
        .mockResolvedValue({ kind: 'ok' })

      const metrics = createMetrics()
      metrics.count('orders_created', 5)
      await metrics.flush()
      metrics.count('orders_created', 2)
      await metrics.flush()

      expect(sentPayloads()[1].resourceMetrics[0].scopeMetrics[0].metrics[0].sum!.dataPoints[0].asDouble).toBe(2)
    })

    it('keeps flushing on the interval', async () => {
      const metrics = createMetrics({ flushIntervalMs: 5000 })
      metrics.count('a', 1)
      await vi.advanceTimersByTimeAsync(5000)
      metrics.count('a', 1)
      await vi.advanceTimersByTimeAsync(5000)
      expect(mockInstance._sendMetricsBatch).toHaveBeenCalledTimes(2)
    })

    it('stops the timer and clears state on reset', async () => {
      const metrics = createMetrics({ flushIntervalMs: 5000 })
      metrics.count('a', 1)
      metrics.reset()
      await vi.advanceTimersByTimeAsync(20000)
      expect(mockInstance._sendMetricsBatch).not.toHaveBeenCalled()
    })

    it('drainWindow returns the built payload synchronously and resets the window', async () => {
      const metrics = createMetrics()
      metrics.count('orders_created', 3)

      const payload = metrics.drainWindow()
      expect(payload!.resourceMetrics[0].scopeMetrics[0].metrics[0].sum!.dataPoints[0].asDouble).toBe(3)

      // The window was consumed: nothing left for the regular flush.
      await metrics.flush()
      expect(mockInstance._sendMetricsBatch).not.toHaveBeenCalled()
    })

    it('retries a merged-back window on the next interval even with no new samples', async () => {
      mockInstance._sendMetricsBatch
        .mockResolvedValueOnce({ kind: 'retry-later', error: new Error('offline') })
        .mockResolvedValue({ kind: 'ok' })

      const metrics = createMetrics({ flushIntervalMs: 5000 })
      metrics.count('orders_created', 5)
      await vi.advanceTimersByTimeAsync(5000)
      expect(mockInstance._sendMetricsBatch).toHaveBeenCalledTimes(1)

      // No new captures — the retained window must not be stranded until shutdown.
      await vi.advanceTimersByTimeAsync(5000)
      expect(mockInstance._sendMetricsBatch).toHaveBeenCalledTimes(2)
      const payload: OtlpMetricsPayload = mockInstance._sendMetricsBatch.mock.calls[1][0]
      expect(payload.resourceMetrics[0].scopeMetrics[0].metrics[0].sum!.dataPoints[0].asDouble).toBe(5)
    })

    it('drainWindow returns null when the window is empty', () => {
      const metrics = createMetrics()
      expect(metrics.drainWindow()).toBeNull()
    })
  })

  describe('guardrails and filtering', () => {
    it('caps distinct series per window and warns once', async () => {
      const metrics = createMetrics({ maxSeriesPerFlush: 2 })
      metrics.count('a', 1)
      metrics.count('b', 1)
      metrics.count('c', 1)
      metrics.count('d', 1)
      metrics.count('a', 1) // existing series still aggregates
      await metrics.flush()

      const sent = sentMetrics()
      expect(sent.map((m) => m.name).sort()).toEqual(['a', 'b'])
      expect(sent.find((m) => m.name === 'a')!.sum!.dataPoints[0].asDouble).toBe(2)
      expect((logger.warn as vi.Mock).mock.calls.length).toBe(1)
    })

    it('re-applies the series cap when merging a failed window back', async () => {
      let resolveSend!: (outcome: SendMetricsBatchOutcome) => void
      mockInstance._sendMetricsBatch
        .mockImplementationOnce(() => new Promise<SendMetricsBatchOutcome>((resolve) => (resolveSend = resolve)))
        .mockResolvedValue({ kind: 'ok' })

      const metrics = createMetrics({ maxSeriesPerFlush: 2 })
      metrics.count('a', 1)
      metrics.count('b', 1)
      const inflight = metrics.flush()
      // New series captured while the failing send is in flight fill the fresh window to the cap.
      metrics.count('c', 1)
      metrics.count('d', 1)
      resolveSend({ kind: 'retry-later', error: new Error('offline') })
      await inflight

      await metrics.flush()

      const payloads = sentPayloads()
      expect(payloads).toHaveLength(2)
      const dataPointCount = payloads[1].resourceMetrics[0].scopeMetrics[0].metrics.reduce(
        (n, m) => n + (m.sum?.dataPoints.length ?? 0),
        0
      )
      expect(dataPointCount).toBeLessThanOrEqual(2)
      expect((logger.warn as vi.Mock).mock.calls.some((c) => String(c[0]).includes('series cap'))).toBe(true)
    })

    it('drops non-finite values and negative counts', async () => {
      const metrics = createMetrics()
      metrics.count('a', NaN)
      metrics.count('a', Infinity)
      metrics.count('a', -1)
      metrics.gauge('b', NaN)
      metrics.histogram('c', -Infinity)
      metrics.gauge('b', -5) // negative gauge is valid
      await metrics.flush()

      const sent = sentMetrics()
      expect(sent).toHaveLength(1)
      expect(sent[0].name).toBe('b')
      expect(sent[0].gauge!.dataPoints[0].asDouble).toBe(-5)
    })

    it('drops samples with unserializable attributes instead of throwing', async () => {
      const metrics = createMetrics()
      const throwingAttrs = {}
      Object.defineProperty(throwingAttrs, 'bad', {
        enumerable: true,
        get() {
          throw new Error('boom')
        },
      })

      expect(() => metrics.count('good', 1, { attributes: { plan: 'free' } })).not.toThrow()
      expect(() => metrics.count('bigint_attr', 1, { attributes: { jobId: BigInt(1) } as any })).not.toThrow()
      expect(() => metrics.count('throwing_attr', 1, { attributes: throwingAttrs as any })).not.toThrow()
      await metrics.flush()

      // Only the well-formed sample ships; the malformed ones are dropped with a warning.
      expect(sentMetrics().map((m) => m.name)).toEqual(['good'])
      const attrWarns = (logger.warn as vi.Mock).mock.calls.filter((c) => String(c[0]).includes('attributes'))
      expect(attrWarns).toHaveLength(2)
    })

    it('drops samples with an empty name', async () => {
      const metrics = createMetrics()
      metrics.count('', 1)
      await metrics.flush()
      expect(mockInstance._sendMetricsBatch).not.toHaveBeenCalled()
    })

    it('applies beforeSend: transform, chain, drop, and throw', async () => {
      const metrics = createMetrics({
        beforeSend: [
          (m) => (m.name === 'dropped' ? null : m),
          (m) => ({ ...m, attributes: { ...m.attributes, processed: true } }),
        ],
      })
      metrics.count('kept', 1)
      metrics.count('dropped', 1)
      await metrics.flush()

      const sent = sentMetrics()
      expect(sent).toHaveLength(1)
      expect(sent[0].name).toBe('kept')
      expect(sent[0].sum!.dataPoints[0].attributes).toContainEqual({
        key: 'processed',
        value: { boolValue: true },
      })
    })

    it('snapshots attributes at capture time — later caller mutation cannot corrupt the series', async () => {
      const metrics = createMetrics()
      const attributes = { plan: 'free' }
      metrics.count('api_calls', 1, { attributes })
      attributes.plan = 'pro'
      metrics.count('api_calls', 1, { attributes })
      await metrics.flush()

      const sent = sentMetrics()
      expect(sent[0].sum!.dataPoints).toHaveLength(2)
      const values = sent[0].sum!.dataPoints.map((dp) => dp.attributes.find((a) => a.key === 'plan')!.value.stringValue)
      expect(values.sort()).toEqual(['free', 'pro'])
    })

    it('warns once when a metric name is reused with a different type, but keeps both series', async () => {
      const metrics = createMetrics()
      metrics.count('throughput', 5)
      metrics.gauge('throughput', 42)
      metrics.gauge('throughput', 43)
      await metrics.flush()

      // Both series still ship — the warning is a dev-time hint, not a drop.
      const sent = sentMetrics()
      expect(sent.some((m) => m.sum)).toBe(true)
      expect(sent.some((m) => m.gauge)).toBe(true)
      const typeWarns = (logger.warn as vi.Mock).mock.calls.filter((c) => String(c[0]).includes('already used'))
      expect(typeWarns).toHaveLength(1)
    })

    it('drops counts made negative by beforeSend', async () => {
      const metrics = createMetrics({
        beforeSend: (m) => ({ ...m, value: -5 }),
      })
      metrics.count('a', 1)
      await metrics.flush()
      expect(mockInstance._sendMetricsBatch).not.toHaveBeenCalled()
    })

    it('drops a sample whose beforeSend result has an unknown type and still sends the rest', async () => {
      const metrics = createMetrics({
        beforeSend: (m) => (m.name === 'bad' ? ({ name: m.name, value: m.value } as any) : m),
      })
      metrics.count('good', 1)
      metrics.count('bad', 1)
      await metrics.flush()

      expect(sentMetrics().map((m) => m.name)).toEqual(['good'])
      expect((logger.warn as vi.Mock).mock.calls.some((c) => String(c[0]).includes('unknown type'))).toBe(true)
    })

    it('drops the sample when beforeSend throws', async () => {
      const metrics = createMetrics({
        beforeSend: () => {
          throw new Error('boom')
        },
      })
      metrics.count('a', 1)
      await metrics.flush()
      expect(mockInstance._sendMetricsBatch).not.toHaveBeenCalled()
    })

    it('no-ops when the host is disabled or opted out', async () => {
      const disabledInstance = createMockInstance({ isDisabled: true })
      const disabled = createMetrics({}, disabledInstance)
      disabled.count('a', 1)
      await disabled.flush()

      const optedOutInstance = createMockInstance({ optedOut: true })
      const optedOut = createMetrics({}, optedOutInstance)
      optedOut.count('a', 1)
      await optedOut.flush()

      expect(disabledInstance._sendMetricsBatch).not.toHaveBeenCalled()
      expect(optedOutInstance._sendMetricsBatch).not.toHaveBeenCalled()
    })
  })

  it('does not hold a later capture at a window a successful flush already closed', async () => {
    let sends = 0
    mockInstance._sendMetricsBatch = vi.fn(async (): Promise<SendMetricsBatchOutcome> => {
      sends += 1
      return sends === 1 ? { kind: 'retry-later', error: new Error('429'), retryAfterMs: 300_000 } : { kind: 'ok' }
    })
    const metrics = createMetrics({ flushIntervalMs: 5000 })

    metrics.count('a', 1)
    await vi.advanceTimersByTimeAsync(5000)
    await metrics.flush()
    const closedAt = Date.now()

    metrics.count('b', 1)
    await vi.advanceTimersByTimeAsync(5000)

    expect(mockInstance._sendMetricsBatch).toHaveBeenCalledTimes(3)
    expect(Date.now() - closedAt).toBeLessThanOrEqual(5000)
  })

  it('releases a series captured mid-flush once that flush closes the window', async () => {
    const metrics = createMetrics({ flushIntervalMs: 10_000 })
    let sends = 0
    mockInstance._sendMetricsBatch = vi.fn(async (): Promise<SendMetricsBatchOutcome> => {
      sends += 1
      if (sends === 1) {
        return { kind: 'retry-later', error: new Error('429'), retryAfterMs: 300_000 }
      }
      await Promise.resolve()
      if (sends === 2) {
        metrics.count('mid', 1)
      }
      return { kind: 'ok' }
    })

    metrics.count('a', 1)
    await vi.advanceTimersByTimeAsync(10_000)
    await vi.advanceTimersByTimeAsync(10_000)
    await metrics.flush()

    await vi.advanceTimersByTimeAsync(10_000)
    expect(mockInstance._sendMetricsBatch).toHaveBeenCalledTimes(3)
  })
})
