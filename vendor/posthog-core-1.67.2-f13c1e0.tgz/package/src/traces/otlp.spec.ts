import {
  buildOtlpSpan,
  buildOtlpTracesPayload,
  buildTracesResourceAttributes,
  msToUnixNanoString,
  spanKindToOtlp,
} from './otlp'
import type { OtlpSpan, ResolvedTracesConfig, SpanRecord } from './types'

const record = (overrides: Partial<SpanRecord> = {}): SpanRecord => ({
  traceId: '4bf92f3577b34da6a3ce929d0e0e4736',
  spanId: '00f067aa0ba902b7',
  name: 'checkout',
  kind: 'internal',
  traceFlags: '01',
  parentIsRemote: false,
  attributes: {},
  events: [],
  startTime: 1_700_000_000_000,
  endTime: 1_700_000_000_080,
  ...overrides,
})

describe('OTLP span encoding', () => {
  describe('msToUnixNanoString', () => {
    it('encodes milliseconds as a nanosecond string', () => {
      expect(msToUnixNanoString(1_700_000_000_000)).toBe('1700000000000000000')
    })

    it('keeps sub-millisecond precision', () => {
      expect(msToUnixNanoString(1_700_000_000_000.5)).toBe('1700000000000500000')
    })

    it('stays exact beyond Number.MAX_SAFE_INTEGER', () => {
      // The whole point of string concatenation over `ms * 1e6`, which would
      // silently lose precision at this magnitude.
      const encoded = msToUnixNanoString(1_700_000_000_123)
      expect(encoded).toBe('1700000000123000000')
      expect(Number(encoded)).toBeGreaterThan(Number.MAX_SAFE_INTEGER)
    })

    it.each([0.9999999, 1.9999999, 999.9999999])(
      'carries a rounded-up fraction into the next millisecond for %p',
      (ms) => {
        // Without the carry the padded fraction gains a seventh digit, producing
        // a malformed timestamp that 400s the whole request. Unreachable from a
        // real clock — float64 quantization at epoch-ms magnitude keeps the
        // fraction well below the carry — but reachable via a caller-supplied
        // `startTime`, which the validity check accepts anywhere in [0, MAX].
        const encoded = msToUnixNanoString(ms)
        expect(encoded).toHaveLength(String(Math.round(ms)).length + 6)
        expect(encoded).toMatch(/^\d+$/)
      }
    )
  })

  describe('spanKindToOtlp', () => {
    it.each([
      ['internal', 1],
      ['server', 2],
      ['client', 3],
      ['producer', 4],
      ['consumer', 5],
    ] as const)('maps %s to %i', (kind, expected) => {
      expect(spanKindToOtlp(kind)).toBe(expected)
    })

    it('defaults to internal', () => {
      expect(spanKindToOtlp(undefined)).toBe(1)
    })
  })

  describe('buildOtlpSpan', () => {
    it('builds the minimal shape', () => {
      expect(buildOtlpSpan(record())).toEqual({
        traceId: '4bf92f3577b34da6a3ce929d0e0e4736',
        spanId: '00f067aa0ba902b7',
        name: 'checkout',
        kind: 1,
        startTimeUnixNano: '1700000000000000000',
        endTimeUnixNano: '1700000000080000000',
        flags: 0x101,
      })
    })

    it('omits status when it was never set', () => {
      expect(buildOtlpSpan(record())).not.toHaveProperty('status')
    })

    it('encodes ok and error status codes', () => {
      expect(buildOtlpSpan(record({ status: { code: 'ok' } })).status).toEqual({ code: 1 })
      expect(buildOtlpSpan(record({ status: { code: 'error', message: 'boom' } })).status).toEqual({
        code: 2,
        message: 'boom',
      })
    })

    it('includes parent, tracestate, attributes and events when present', () => {
      const span = buildOtlpSpan(
        record({
          parentSpanId: 'b7ad6b7169203331',
          traceState: 'vendor=abc',
          attributes: { plan: 'pro' },
          events: [{ name: 'cache miss', timestamp: 1_700_000_000_040 }],
        })
      )
      expect(span.parentSpanId).toBe('b7ad6b7169203331')
      expect(span.traceState).toBe('vendor=abc')
      expect(span.attributes).toEqual([{ key: 'plan', value: { stringValue: 'pro' } }])
      expect(span.events).toEqual([{ name: 'cache miss', timeUnixNano: '1700000000040000000' }])
    })

    it('carries an event attribute drop as the proto counter', () => {
      const span = buildOtlpSpan(
        record({
          events: [{ name: 'query', timestamp: 1_700_000_000_040, droppedAttributesCount: 3 }],
        })
      )
      expect(span.events?.[0]).toMatchObject({ name: 'query', droppedAttributesCount: 3 })
    })

    it.each([
      ['none were dropped', 0],
      ['a hook wrote a negative', -2],
      ['a hook wrote a non-number', 'lots' as unknown as number],
    ])('omits the event drop counter when %s', (_label, dropped) => {
      // Coerced like the span's own counters: a non-integer here is refused for
      // the whole request, taking unrelated spans with it.
      const span = buildOtlpSpan(
        record({
          events: [{ name: 'query', timestamp: 1_700_000_000_040, droppedAttributesCount: dropped }],
        })
      )
      expect(span.events?.[0].droppedAttributesCount).toBeUndefined()
    })

    it('sets the sampled bit and marks a root span as known-not-remote', () => {
      // A root span has no parent context to be remote, which the OTel Go and
      // Java exporters also report as known-not-remote rather than unknown.
      expect(buildOtlpSpan(record()).flags).toBe(0x101)
    })

    it('marks a local parent as known-not-remote', () => {
      expect(buildOtlpSpan(record({ parentSpanId: 'b7ad6b7169203331' })).flags).toBe(0x101)
    })

    it('marks a parent that arrived as a header as remote', () => {
      expect(buildOtlpSpan(record({ parentSpanId: 'b7ad6b7169203331', parentIsRemote: true })).flags).toBe(0x301)
    })

    it('propagates an inbound sampled-out flag rather than overriding it', () => {
      // The span is still recorded and exported; what the wire says is the
      // decision the head sampler made.
      expect(buildOtlpSpan(record({ traceFlags: '00', parentIsRemote: true })).flags).toBe(0x300)
    })

    it('falls back to sampled when the flags byte is unusable', () => {
      expect(buildOtlpSpan(record({ traceFlags: 'zz' })).flags).toBe(0x101)
    })
  })

  describe('buildTracesResourceAttributes', () => {
    const config = (partial: Partial<ResolvedTracesConfig> = {}): ResolvedTracesConfig => ({
      flushIntervalMs: 5000,
      maxExportBatchSize: 512,
      maxQueueSize: 2048,
      beforeSpanSend: [],
      maxAttributesPerSpan: 128,
      maxEventsPerSpan: 128,
      maxAttributesPerEvent: 128,
      maxAttributeValueLength: 8192,
      maxLiveSpans: 10000,
      maxSpanAgeMs: 3600000,
      ...partial,
    })

    it('always emits service.name', () => {
      // The server reads service_name only from this attribute and stores an
      // empty string when it's missing, leaving spans unattributable.
      expect(buildTracesResourceAttributes(config(), 'posthog-node', '1.0.0')['service.name']).toBe('unknown_service')
    })

    it('uses the configured service name', () => {
      expect(buildTracesResourceAttributes(config({ serviceName: 'checkout' }), 'posthog-node', '1.0.0')).toMatchObject(
        {
          'service.name': 'checkout',
        }
      )
    })

    it('includes environment and version only when set', () => {
      const attributes = buildTracesResourceAttributes(
        config({ environment: 'production', serviceVersion: '2.1.0' }),
        'posthog-node',
        '1.0.0'
      )
      expect(attributes['deployment.environment']).toBe('production')
      expect(attributes['service.version']).toBe('2.1.0')
      expect(buildTracesResourceAttributes(config(), 'posthog-node', '1.0.0')).not.toHaveProperty(
        'deployment.environment'
      )
    })

    it('protects SDK identity keys from user resource attributes', () => {
      const attributes = buildTracesResourceAttributes(
        config({ resourceAttributes: { 'telemetry.sdk.name': 'custom', 'host.name': 'web-01' } }),
        'posthog-node',
        '1.0.0'
      )
      expect(attributes['telemetry.sdk.name']).toBe('posthog-node')
      expect(attributes['host.name']).toBe('web-01')
    })
  })

  describe('buildOtlpTracesPayload', () => {
    it('produces one resource, one scope, N spans', () => {
      const spans = [buildOtlpSpan(record()), buildOtlpSpan(record({ name: 'other' }))]
      const payload = buildOtlpTracesPayload(spans, { 'service.name': 'checkout' }, 'posthog-node', '1.0.0')

      expect(payload.resourceSpans).toHaveLength(1)
      expect(payload.resourceSpans[0].scopeSpans).toHaveLength(1)
      expect(payload.resourceSpans[0].scopeSpans[0].spans).toHaveLength(2)
      expect(payload.resourceSpans[0].scopeSpans[0].scope).toEqual({ name: 'posthog-node', version: '1.0.0' })
      expect(payload.resourceSpans[0].resource.attributes).toEqual([
        { key: 'service.name', value: { stringValue: 'checkout' } },
      ])
    })
  })

  describe('golden wire fixture', () => {
    it('matches the shape the ingestion service accepts', () => {
      // Pinned against the OTLP/JSON encoding the capture-logs service's own
      // trace fixtures use: hex ids, string nanosecond timestamps, integer kind
      // and status enums, and stringified int64 attribute values.
      const payload = buildOtlpTracesPayload(
        [
          buildOtlpSpan(
            record({
              parentSpanId: 'b7ad6b7169203331',
              name: 'GET /users/:id',
              kind: 'server',
              status: { code: 'error', message: 'boom' },
              attributes: {
                posthogDistinctId: 'user-123',
                sessionId: 'session-123',
                'http.status_code': 500,
                'http.duration_ratio': 0.25,
                cached: false,
              },
              events: [
                {
                  name: 'exception',
                  timestamp: 1_700_000_000_040,
                  attributes: { 'exception.type': 'TypeError', 'exception.message': 'boom' },
                },
              ],
            })
          ),
        ],
        { 'service.name': 'checkout-api', 'telemetry.sdk.name': 'posthog-node' },
        'posthog-node',
        '1.0.0'
      )

      expect(payload).toEqual({
        resourceSpans: [
          {
            resource: {
              attributes: [
                { key: 'service.name', value: { stringValue: 'checkout-api' } },
                { key: 'telemetry.sdk.name', value: { stringValue: 'posthog-node' } },
              ],
            },
            scopeSpans: [
              {
                scope: { name: 'posthog-node', version: '1.0.0' },
                spans: [
                  {
                    traceId: '4bf92f3577b34da6a3ce929d0e0e4736',
                    spanId: '00f067aa0ba902b7',
                    parentSpanId: 'b7ad6b7169203331',
                    name: 'GET /users/:id',
                    kind: 2,
                    startTimeUnixNano: '1700000000000000000',
                    endTimeUnixNano: '1700000000080000000',
                    flags: 0x101,
                    attributes: [
                      { key: 'posthogDistinctId', value: { stringValue: 'user-123' } },
                      { key: 'sessionId', value: { stringValue: 'session-123' } },
                      { key: 'http.status_code', value: { intValue: '500' } },
                      { key: 'http.duration_ratio', value: { doubleValue: 0.25 } },
                      { key: 'cached', value: { boolValue: false } },
                    ],
                    events: [
                      {
                        name: 'exception',
                        timeUnixNano: '1700000000040000000',
                        attributes: [
                          { key: 'exception.type', value: { stringValue: 'TypeError' } },
                          { key: 'exception.message', value: { stringValue: 'boom' } },
                        ],
                      },
                    ],
                    status: { code: 2, message: 'boom' },
                  },
                ],
              },
            ],
          },
        ],
      })
    })
  })
})

describe('wire string safety', () => {
  const lone = 'value \u{1F680}'.slice(0, 7)

  const encode = (record: Partial<SpanRecord> = {}): OtlpSpan =>
    buildOtlpSpan({
      traceId: 'a'.repeat(32),
      spanId: 'b'.repeat(16),
      name: 'checkout',
      kind: 'internal',
      attributes: {},
      events: [],
      startTime: 1,
      endTime: 2,
      ...record,
    } as SpanRecord)

  it('replaces a lone surrogate in every free-text field', () => {
    const span = encode({
      name: lone,
      traceState: `vendor=${lone}`,
      status: { code: 'error', message: lone },
      events: [{ name: lone, timestamp: 1 }],
    })

    expect(span.name).not.toContain('\ud83d')
    expect(span.events?.[0].name).not.toContain('\ud83d')
    expect(span.status?.message).not.toContain('\ud83d')
    expect(span.traceState).not.toContain('\ud83d')
  })

  it('keeps the span when a status message cannot be stringified', () => {
    const hostile = {
      toString() {
        throw new Error('toString exploded')
      },
    }
    const span = encode({ status: { code: 'error', message: hostile as unknown as string } })

    expect(span.name).toBe('checkout')
    expect(span.status?.message).toBe('[Unserializable]')
  })

  it('coerces a non-string status message', () => {
    const span = encode({ status: { code: 'error', message: 500 as unknown as string } })

    expect(span.status?.message).toBe('500')
  })

  it('falls back to internal for a prototype key passed as a kind', () => {
    expect(spanKindToOtlp('__proto__' as never)).toBe(1)
    expect(spanKindToOtlp('toString' as never)).toBe(1)
  })
})
