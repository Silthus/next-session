export type PostHogCoreOptions = {
  /**
   * PostHog API host, usually 'https://us.i.posthog.com' or 'https://eu.i.posthog.com'
   *
   * @default 'https://us.i.posthog.com'
   */
  host?: string
  /**
   * The number of events to queue before sending to PostHog (flushing)
   *
   * @default 20
   */
  flushAt?: number
  /**
   * The interval in milliseconds between periodic flushes
   *
   * @default 10000
   */
  flushInterval?: number
  /**
   * The maximum number of queued messages to be flushed as part of a single batch (must be higher than `flushAt`)
   *
   * @default 100
   */
  maxBatchSize?: number
  /**
   * The maximum number of cached messages either in memory or on the local storage (must be higher than `flushAt`)
   *
   * @default 1000
   */
  maxQueueSize?: number
  /**
   * If set to true the SDK is essentially disabled (useful for local environments where you don't want to track anything)
   *
   * @default false
   */
  disabled?: boolean
  /**
   * If set to false the SDK will not track until the `optIn` function is called.
   *
   * @default true
   */
  defaultOptIn?: boolean
  /**
   * Whether to strip URL fragments (`#...`) from automatically captured URL fields.
   * Disabled by default for backwards compatibility. Set to `true` to strip hashes from:
   *
   * - `$current_url` on automatically captured browser events, including `$pageview`
   * - `$initial_current_url`
   * - `$session_entry_url`
   * - `$elements[*].attr__href` and `$external_click_url` for autocapture and dead-click autocapture
   * - Next.js Pages Router `$pageview` `$current_url`
   * - web vitals `$current_url`
   * - logs `url.full`
   * - conversations `current_url` and `request_url`
   * - session replay rrweb meta/custom-event `href` URLs
   * - heatmap data URLs
   *
   * If your SPA relies on hash-based routes for analytics, enabling this is a breaking behavior change.
   * If you want to capture hashes selectively, leave this as `false` and use `before_send` to remove
   * sensitive hash values before events are sent.
   *
   * @default false
   */
  disable_capture_url_hashes?: boolean
  /**
   * Whether to track that `getFeatureFlag` was called (used by Experiments)
   *
   * In posthog-node this is also the default for reads from an `evaluateFlags()` snapshot
   * (`isEnabled()` / `getFlag()`). Pass `sendFeatureFlagEvents` to one of those reads, or to a
   * single-flag getter, to override it for that call.
   *
   * @default true
   */
  sendFeatureFlagEvent?: boolean
  /**
   * Whether to load feature flags when initialized or not
   *
   * @default true
   */
  preloadFeatureFlags?: boolean
  /**
   * Advanced: whether to disable fetching and evaluating feature flags from PostHog entirely.
   *
   * When set to true, `reloadFeatureFlags()` and the reloads triggered by `identify()`,
   * `group()`, `setPersonPropertiesForFlags()` and `reset()` become no-ops, and any request
   * to the flags endpoint that still goes out (e.g. to fetch remote config or surveys)
   * carries `disable_flags: true` so the server skips flag evaluation. Flag values must be
   * supplied via the `bootstrap` option or `updateFlags()` instead; `getFeatureFlag()` and
   * related methods keep working against those values. Until `updateFlags()` runs, reads
   * return their not-loaded defaults, so use `bootstrap` for any flags needed at startup.
   * Equivalent to the web SDK's `advanced_disable_feature_flags`.
   *
   * Note: surveys gated on feature flags will not evaluate unless the survey targeting
   * flags are also provided via `updateFlags()`. This option cannot be toggled at runtime.
   * `posthog-node` inherits this option but does not implement it (no-op).
   *
   * @default false
   */
  disableRemoteFeatureFlags?: boolean
  /**
   * Whether to load remote config when initialized or not
   *
   * @deprecated Remote config is now always loaded and this option is a no-op. It will be removed in a future version.
   * @default false
   */
  disableRemoteConfig?: boolean
  /**
   * Whether to load surveys when initialized or not
   * Requires the `PostHogSurveyProvider` to be used
   *
   * @default false
   */
  disableSurveys?: boolean
  /** Option to bootstrap the library with given distinctId and feature flags */
  bootstrap?: {
    distinctId?: string
    isIdentifiedId?: boolean
    featureFlags?: Record<string, FeatureFlagValue>
    featureFlagPayloads?: Record<string, JsonType>
  }
  /**
   * How many times we will retry HTTP requests
   *
   * @default 3
   */
  fetchRetryCount?: number
  /**
   * The delay between HTTP request retries in milliseconds
   *
   * @default 3000
   */
  fetchRetryDelay?: number
  /**
   * Timeout in milliseconds for any calls
   *
   * @default 10000
   */
  requestTimeout?: number
  /**
   * Timeout in milliseconds for feature flag calls
   *
   * @default 10000 for stateful clients, 3000 for stateless
   */
  featureFlagsRequestTimeoutMs?: number
  /**
   * How many times feature flag requests retry after a transient network error.
   * Set to 0 to disable feature flag request retries.
   *
   * @default 1
   */
  featureFlagsRequestMaxRetries?: number
  /**
   * Timeout in milliseconds for remote config calls
   *
   * @default 3000
   */
  remoteConfigRequestTimeoutMs?: number
  /**
   * For Session Analysis how long before we expire a session in seconds
   *
   * @default 1800
   */
  sessionExpirationTimeSeconds?: number
  /**
   * Whether to disable GZIP compression
   *
   * @default false
   */
  disableCompression?: boolean
  /**
   * Whether to disable GeoIP lookups
   *
   * @default false
   */
  disableGeoip?: boolean
  /**
   * Special flag to indicate ingested data is for a historical migration
   *
   * @default false
   */
  historicalMigration?: boolean
  /**
   * Evaluation contexts for feature flags.
   * When set, only feature flags that have at least one matching evaluation tag
   * will be evaluated for this SDK instance. Feature flags with no evaluation tags
   * will always be evaluated.
   *
   * Examples: ['production', 'web', 'mobile']
   *
   * @default undefined
   */
  evaluationContexts?: readonly string[]
  /**
   * Evaluation environments for feature flags.
   * @deprecated Use evaluationContexts instead. This property will be removed in a future version.
   */
  evaluationEnvironments?: readonly string[]

  /**
   * Determines when to create Person Profiles for users.
   *
   * - 'always': Always create a person profile for every user (anonymous and identified).
   * - 'identified_only': Only create a person profile when the user is identified via identify(), alias(), or group().
   *   Events captured before identification will NOT have person profiles and will be anonymous events.
   * - 'never': Never create person profiles. identify(), alias(), and group() will be no-ops.
   *
   * @default 'identified_only'
   *
   * @example
   * ```ts
   * // Only create profiles when users are identified (recommended for most apps)
   * const posthog = new PostHog('<api_key>', {
   *   personProfiles: 'identified_only',
   * })
   *
   * // Later when user logs in:
   * posthog.identify('user-123', { email: 'user@example.com' })
   * ```
   *
   * @example
   * ```ts
   * // Always create profiles (for apps where you want to track all users)
   * const posthog = new PostHog('<api_key>', {
   *   personProfiles: 'always',
   * })
   * ```
   *
   * @example
   * ```ts
   * // Never create profiles (anonymous analytics only)
   * const posthog = new PostHog('<api_key>', {
   *   personProfiles: 'never',
   * })
   * ```
   */
  personProfiles?: 'always' | 'identified_only' | 'never'

  /**
   * Allows modification or dropping of events before they're sent to PostHog.
   * If an array is provided, the functions are run in order.
   * If a function returns null, the event will be dropped.
   */
  before_send?: BeforeSendFn | BeforeSendFn[]

  /**
   * A list of hostnames for which to inject PostHog tracing headers
   * (X-POSTHOG-DISTINCT-ID, X-POSTHOG-SESSION-ID) on outgoing `fetch` requests.
   *
   * Use this to link requests made from your app to session replays and LLM traces
   * in PostHog. When set, the global `fetch` is patched on initialization and the
   * headers are added to requests whose hostname matches one of the entries.
   *
   * Requires the SDK to wire up `patchFetchForTracingHeaders` against this option
   * (currently supported in posthog-react-native).
   */
  addTracingHeaders?: string[]
}

export enum PostHogPersistedProperty {
  AnonymousId = 'anonymous_id',
  DistinctId = 'distinct_id',
  Props = 'props',
  EnablePersonProcessing = 'enable_person_processing',
  PersonMode = 'person_mode', // 'identified' | 'anonymous'
  FeatureFlagDetails = 'feature_flag_details',
  FeatureFlags = 'feature_flags',
  FeatureFlagPayloads = 'feature_flag_payloads',
  BootstrapFeatureFlagDetails = 'bootstrap_feature_flag_details',
  BootstrapFeatureFlags = 'bootstrap_feature_flags',
  BootstrapFeatureFlagPayloads = 'bootstrap_feature_flag_payloads',
  OverrideFeatureFlags = 'override_feature_flags',
  Queue = 'queue',
  // Isolated capture queue for events that must not share a send cycle with the
  // main queue. Only used by posthog-node today, to keep `$ai_*` events on the
  // legacy (v0) transport while other events move to Capture V1 — segregated so a
  // failure on one route can't re-send events already accepted on the other.
  AiQueue = 'ai_queue',
  AiCaptureQueue = 'ai_capture_queue',
  // Logs queue. Individual SDKs may route this key to an isolated storage
  // instance if they want to separate logs write volume from main state.
  LogsQueue = 'logs_queue',
  OptedOut = 'opted_out',
  SessionId = 'session_id',
  SessionStartTimestamp = 'session_start_timestamp',
  SessionLastTimestamp = 'session_timestamp',
  PersonProperties = 'person_properties',
  GroupProperties = 'group_properties',
  InstalledAppBuild = 'installed_app_build', // only used by posthog-react-native
  InstalledAppVersion = 'installed_app_version', // only used by posthog-react-native
  SessionReplay = 'session_replay', // only used by posthog-react-native
  // Set by a manual registerPushNotificationToken(): the native SDK persists the
  // subscription across launches, so cleanup (unregister/reset) must boot native even in a
  // process where nothing else initialized it. Only used by posthog-react-native.
  PushRegistered = 'push_registered',
  // Session id for which an event trigger has activated session replay. only used by posthog-react-native
  SessionReplayEventTriggerActivatedSession = 'session_replay_event_trigger_activated_session',
  SurveyLastSeenDate = 'survey_last_seen_date', // only used by posthog-react-native
  SurveysInProgress = 'surveys_in_progress', // only used by posthog-react-native
  SurveysSeen = 'surveys_seen', // only used by posthog-react-native
  Surveys = 'surveys', // only used by posthog-react-native
  RemoteConfig = 'remote_config',
  FlagsEndpointWasHit = 'flags_endpoint_was_hit', // only used by posthog-react-native
  DeviceId = 'device_id', // only used by posthog-react-native
}

export type PostHogFetchBodyBytes = Uint8Array & { buffer: ArrayBuffer }

export type PostHogFetchOptions = {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH'
  mode?: 'no-cors'
  credentials?: 'omit'
  headers: { [key: string]: string }
  body?: string | Blob | PostHogFetchBodyBytes
  signal?: AbortSignal
}

// Check out posthog-js for these additional options and try to keep them in sync
export type PostHogCaptureOptions = {
  /** If provided overrides the auto-generated event UUID. Must be a valid UUID. */
  uuid?: string
  /** If provided, overrides the auto-generated timestamp. UTC is preferred; non-UTC input is converted to UTC. */
  timestamp?: Date
  disableGeoip?: boolean
  /**
   * Internal flag set by captureException() to indicate this $exception
   * event originated from the proper exception capture path. Used to warn users who call
   * capture('$exception') directly.
   */
  _originatedFromCaptureException?: boolean
}

export type PostHogFetchResponse = {
  status: number
  text: () => Promise<string>
  json: () => Promise<any>
  headers?: {
    get(name: string): string | null
  }
  body?: ReadableStream<Uint8Array> | null
}

export type PostHogQueueItem = {
  message?: PostHogEventProperties
  callback?: (err: unknown) => void
}

export type PostHogEventProperties = {
  [key: string]: JsonType
}

export type PostHogGroupProperties = {
  [type: string]: string | number
}

export type PostHogAutocaptureElement = {
  $el_text?: string
  tag_name: string
  href?: string
  nth_child?: number
  nth_of_type?: number
  order?: number
} & PostHogEventProperties
// Any key prefixed with `attr__` can be added

export enum Compression {
  GZipJS = 'gzip-js',
  Base64 = 'base64',
}

export type PostHogRemoteConfig = {
  sessionRecording?:
    | boolean
    | {
        [key: string]: JsonType
      }

  /**
   * Supported compression algorithms
   */
  supportedCompression?: Compression[]

  /**
   * Whether surveys are enabled
   */
  surveys?: boolean | Survey[]

  /**
   * Indicates if the team has any flags enabled (if not we don't need to load them)
   */
  hasFeatureFlags?: boolean

  /**
   * Error tracking remote config.
   * Either a boolean (false = disabled) or a map with configuration.
   * When a map, `autocaptureExceptions` (boolean) controls whether automatic exception capture is enabled remotely.
   */
  errorTracking?:
    | boolean
    | {
        [key: string]: JsonType
      }

  /**
   * Capture performance remote config.
   * Either a boolean (false = disabled) or a map with configuration.
   * When a map, `network_timing` (boolean) controls whether network timing capture is enabled remotely.
   */
  capturePerformance?:
    | boolean
    | {
        [key: string]: JsonType
      }

  /**
   * Logs feature remote config. When a map, `captureConsoleLogs` (boolean)
   * is the local opt-in flag for `console.*` autocapture (read by the JS
   * SDK's `PostHogLogs` extension to decide whether to load the autocapture
   * bundle).
   */
  logs?:
    | boolean
    | {
        [key: string]: JsonType
      }
}

export type FeatureFlagValue = string | boolean

/**
 * Result of evaluating a feature flag, including both the flag value and its payload.
 */
export type FeatureFlagResult = {
  readonly key: string
  /** Whether the returned feature flag evaluation is enabled. `false` is a conclusive off result. */
  readonly enabled: boolean
  readonly variant?: string
  readonly payload?: JsonType
}

export type FeatureFlagResultOptions = {
  /** Whether to send a $feature_flag_called event. Defaults to true. */
  sendEvent?: boolean
}

export type IsFeatureEnabledOptions = FeatureFlagResultOptions & {
  /** Value to return when the flag has no value, e.g. flags have not loaded yet or no flag with that key exists. */
  defaultValue?: boolean
}

export type PostHogFlagsResponse = Omit<PostHogRemoteConfig, 'hasFeatureFlags'> & {
  featureFlags: {
    [key: string]: FeatureFlagValue
  }
  featureFlagPayloads: {
    [key: string]: JsonType
  }
  flags: {
    [key: string]: FeatureFlagDetail
  }
  errorsWhileComputingFlags: boolean
  sessionRecording?:
    | boolean
    | {
        [key: string]: JsonType
      }
  quotaLimited?: string[]
  requestId?: string
  evaluatedAt?: number // Unix timestamp in milliseconds
  /**
   * Server-controlled gate for minimal `$feature_flag_called` events. `true` only when the
   * project opted in; omitted otherwise. Absence always means full events.
   */
  minimalFlagCalledEvents?: boolean
}

export type PostHogFeatureFlagsResponse = PartialWithRequired<
  PostHogFlagsResponse,
  'flags' | 'featureFlags' | 'featureFlagPayloads' | 'requestId'
>

/**
 * Creates a type with all properties of T, but makes only K properties required while the rest remain optional.
 *
 * @template T - The base type containing all properties
 * @template K - Union type of keys from T that should be required
 *
 * @example
 * interface User {
 *   id: number;
 *   name: string;
 *   email?: string;
 *   age?: number;
 * }
 *
 * // Makes 'id' and 'name' required, but 'email' and 'age' optional
 * type RequiredUser = PartialWithRequired<User, 'id' | 'name'>;
 *
 * const user: RequiredUser = {
 *   id: 1,      // Must be provided
 *   name: "John" // Must be provided
 *   // email and age are optional
 * };
 */
export type PartialWithRequired<T, K extends keyof T> = {
  [P in K]: T[P] // Required fields
} & {
  [P in Exclude<keyof T, K>]?: T[P] // Optional fields
}

/**
 * These are the fields we care about from PostHogFlagsResponse for feature flags.
 */
export type PostHogFeatureFlagDetails = PartialWithRequired<
  PostHogFlagsResponse,
  'flags' | 'featureFlags' | 'featureFlagPayloads' | 'requestId'
>

/**
 * Models the response from the v1 `/flags` endpoint.
 */
export type PostHogV1FlagsResponse = Omit<PostHogFlagsResponse, 'flags'>

/**
 * Models the response from the v2 `/flags` endpoint.
 */
export type PostHogV2FlagsResponse = Omit<PostHogFlagsResponse, 'featureFlags' | 'featureFlagPayloads'>

/**
 * The format of the flags object in persisted storage
 *
 * When we pull flags from persistence, we can normalize them to PostHogFeatureFlagDetails
 * so that we can support v1 and v2 of the API.
 */
export type PostHogFlagsStorageFormat = Pick<PostHogFeatureFlagDetails, 'flags'> &
  Partial<Pick<PostHogFlagsResponse, 'requestId' | 'evaluatedAt' | 'minimalFlagCalledEvents'>> & {
    errorsWhileComputingFlags?: boolean
    quotaLimited?: string[]
    requestError?: FeatureFlagRequestError
  }

/**
 * Models legacy flags and payloads return type for many public methods.
 */
export type PostHogFlagsAndPayloadsResponse = Partial<
  Pick<PostHogFlagsResponse, 'featureFlags' | 'featureFlagPayloads'>
>

export type JsonType = string | number | boolean | null | { [key: string]: JsonType } | Array<JsonType> | JsonType[]

export type FetchLike = (url: string, options: PostHogFetchOptions) => Promise<PostHogFetchResponse>

/**
 * Error type constants for the $feature_flag_error property.
 *
 * These values are sent in analytics events to track flag evaluation failures.
 * They should not be changed without considering impact on existing dashboards
 * and queries that filter on these values.
 *
 * Error values:
 *   ERRORS_WHILE_COMPUTING: Server returned errorsWhileComputingFlags=true
 *   FLAG_MISSING: Requested flag not in API response
 *   LOCAL_EVALUATION_INCONCLUSIVE: Flag has a loaded local definition but local evaluation could not resolve it
 *   QUOTA_LIMITED: Rate/quota limit exceeded
 *   TIMEOUT: Request timed out
 *   CONNECTION_ERROR: Network connection failed
 *   apiError: HTTP error with status code (e.g., api_error_500)
 */
export const FeatureFlagError = {
  ERRORS_WHILE_COMPUTING: 'errors_while_computing_flags',
  FLAG_MISSING: 'flag_missing',
  LOCAL_EVALUATION_INCONCLUSIVE: 'local_evaluation_inconclusive',
  QUOTA_LIMITED: 'quota_limited',
  TIMEOUT: 'timeout',
  CONNECTION_ERROR: 'connection_error',
  UNKNOWN_ERROR: 'unknown_error',
  apiError: (status: number): string => `api_error_${status}`,
} as const

export type FeatureFlagErrorType =
  | (typeof FeatureFlagError)[Exclude<keyof typeof FeatureFlagError, 'apiError'>]
  | ReturnType<typeof FeatureFlagError.apiError>
  | string

/**
 * Represents an error that occurred during a feature flag request.
 */
export type FeatureFlagRequestError = {
  type: 'timeout' | 'connection_error' | 'api_error' | 'unknown_error'
  statusCode?: number
}

/**
 * Result type for getFlags that includes either a successful response or error information.
 */
export type GetFlagsResult =
  | { success: true; response: PostHogFeatureFlagsResponse }
  | { success: false; error: FeatureFlagRequestError }

export type FeatureFlagDetail = {
  key: string
  enabled: boolean
  variant: string | undefined
  reason: EvaluationReason | undefined
  metadata: FeatureFlagMetadata | undefined
  failed?: boolean
}

export type FeatureFlagMetadata = {
  id: number | undefined
  version: number | undefined
  description: string | undefined
  // Payloads in the response are always JSON encoded as a string
  payload: string | undefined
  /** Whether the flag is linked to an experiment. Absent when the server does not report it. */
  has_experiment?: boolean
}

export type EvaluationReason = {
  code: string | undefined
  condition_index: number | undefined
  description: string | undefined
}

// survey types
export type SurveyAppearance = {
  // keep in sync with frontend/src/types.ts -> SurveyAppearance
  backgroundColor?: string
  // Optional override for main survey text color. If not set, auto-calculated from backgroundColor.
  textColor?: string
  submitButtonColor?: string
  // deprecate submit button text eventually
  submitButtonText?: string
  // Optional override for submit button text color. If not set, auto-calculated from submitButtonColor.
  submitButtonTextColor?: string
  ratingButtonColor?: string
  ratingButtonActiveColor?: string
  inputBackground?: string
  // Optional override for input and rating button text color. If not set, auto-calculated from inputBackground.
  inputTextColor?: string
  autoDisappear?: boolean
  displayThankYouMessage?: boolean
  thankYouMessageHeader?: string
  thankYouMessageDescription?: string
  thankYouMessageDescriptionContentType?: SurveyQuestionDescriptionContentType
  thankYouMessageCloseButtonText?: string
  // Optional intro screen shown before the first question — the leading mirror of the
  // confirmation message. Dismissed with a button; records no response and does not count
  // toward completion or partial-response metrics.
  displayIntroScreen?: boolean
  introScreenHeader?: string
  introScreenDescription?: string
  introScreenDescriptionContentType?: SurveyQuestionDescriptionContentType
  introScreenButtonText?: string
  borderColor?: string
  position?: SurveyPosition
  placeholder?: string
  shuffleQuestions?: boolean
  surveyPopupDelaySeconds?: number
  // Show a "Back" button on questions after the first, allowing respondents to return to a previously visited question. Defaults to false.
  allowGoBack?: boolean
  // Optional override for the back button label.
  backButtonText?: string
  // widget options
  widgetType?: SurveyWidgetType
  widgetSelector?: string
  widgetLabel?: string
  widgetColor?: string
}

export const SurveyPosition = {
  TopLeft: 'top_left',
  TopCenter: 'top_center',
  TopRight: 'top_right',
  MiddleLeft: 'middle_left',
  MiddleCenter: 'middle_center',
  MiddleRight: 'middle_right',
  Left: 'left',
  Right: 'right',
  Center: 'center',
} as const
export type SurveyPosition = (typeof SurveyPosition)[keyof typeof SurveyPosition]

export const SurveyWidgetType = {
  Button: 'button',
  Tab: 'tab',
  Selector: 'selector',
} as const
export type SurveyWidgetType = (typeof SurveyWidgetType)[keyof typeof SurveyWidgetType]

export const SurveyType = {
  Popover: 'popover',
  API: 'api',
  Widget: 'widget',
  ExternalSurvey: 'external_survey',
} as const
export type SurveyType = (typeof SurveyType)[keyof typeof SurveyType]

export type SurveyQuestion = BasicSurveyQuestion | LinkSurveyQuestion | RatingSurveyQuestion | MultipleSurveyQuestion

export const SurveyQuestionDescriptionContentType = {
  Html: 'html',
  Text: 'text',
} as const
export type SurveyQuestionDescriptionContentType =
  (typeof SurveyQuestionDescriptionContentType)[keyof typeof SurveyQuestionDescriptionContentType]

// Survey validation types
export const SurveyValidationType = {
  MinLength: 'min_length',
  MaxLength: 'max_length',
} as const
export type SurveyValidationType = (typeof SurveyValidationType)[keyof typeof SurveyValidationType]

export interface SurveyValidationRule {
  type: SurveyValidationType
  value?: number
  errorMessage?: string
}

export interface SurveyTranslation {
  name?: string
  thankYouMessageHeader?: string
  thankYouMessageDescription?: string
  thankYouMessageCloseButtonText?: string
  introScreenHeader?: string
  introScreenDescription?: string
  introScreenButtonText?: string
  submitButtonText?: string
  backButtonText?: string
}

export interface SurveyQuestionTranslation {
  question?: string
  description?: string | null
  buttonText?: string
  link?: string | null
  lowerBoundLabel?: string
  upperBoundLabel?: string
  choices?: string[]
}

type SurveyQuestionBase = {
  question: string
  id: string
  description?: string | null
  descriptionContentType?: SurveyQuestionDescriptionContentType
  optional?: boolean
  buttonText?: string
  originalQuestionIndex: number
  branching?: NextQuestionBranching | EndBranching | ResponseBasedBranching | SpecificQuestionBranching
  validation?: SurveyValidationRule[]
  translations?: Record<string, SurveyQuestionTranslation>
}

export type BasicSurveyQuestion = SurveyQuestionBase & {
  type: typeof SurveyQuestionType.Open
}

export type LinkSurveyQuestion = SurveyQuestionBase & {
  type: typeof SurveyQuestionType.Link
  link?: string | null
}

export type RatingSurveyQuestion = SurveyQuestionBase & {
  type: typeof SurveyQuestionType.Rating
  display: SurveyRatingDisplay
  scale: 2 | 3 | 5 | 7 | 10
  lowerBoundLabel: string
  upperBoundLabel: string
  skipSubmitButton?: boolean
}

export const SurveyRatingDisplay = {
  Number: 'number',
  Emoji: 'emoji',
} as const
export type SurveyRatingDisplay = (typeof SurveyRatingDisplay)[keyof typeof SurveyRatingDisplay]

export type MultipleSurveyQuestion = SurveyQuestionBase & {
  type: typeof SurveyQuestionType.SingleChoice | typeof SurveyQuestionType.MultipleChoice
  choices: string[]
  hasOpenChoice?: boolean
  shuffleOptions?: boolean
  skipSubmitButton?: boolean
}

export const SurveyQuestionType = {
  Open: 'open',
  MultipleChoice: 'multiple_choice',
  SingleChoice: 'single_choice',
  Rating: 'rating',
  Link: 'link',
} as const
export type SurveyQuestionType = (typeof SurveyQuestionType)[keyof typeof SurveyQuestionType]

export const SurveyQuestionBranchingType = {
  NextQuestion: 'next_question',
  End: 'end',
  ResponseBased: 'response_based',
  SpecificQuestion: 'specific_question',
} as const
export type SurveyQuestionBranchingType = (typeof SurveyQuestionBranchingType)[keyof typeof SurveyQuestionBranchingType]

export type NextQuestionBranching = {
  type: typeof SurveyQuestionBranchingType.NextQuestion
}

export type EndBranching = {
  type: typeof SurveyQuestionBranchingType.End
}

export type ResponseBasedBranching = {
  type: typeof SurveyQuestionBranchingType.ResponseBased
  responseValues: Record<string, any>
}

export type SpecificQuestionBranching = {
  type: typeof SurveyQuestionBranchingType.SpecificQuestion
  index: number
}

export type SurveyResponse = {
  surveys: Survey[]
}

export type SurveyResponseValue = string | number | string[] | null

export type SurveyResponses = Record<string, SurveyResponseValue>

export type SurveyCallback = (surveys: Survey[]) => void

export const SurveyMatchType = {
  Regex: 'regex',
  NotRegex: 'not_regex',
  Exact: 'exact',
  IsNot: 'is_not',
  Icontains: 'icontains',
  NotIcontains: 'not_icontains',
} as const
export type SurveyMatchType = (typeof SurveyMatchType)[keyof typeof SurveyMatchType]

export type PropertyMatchType = SurveyMatchType
export type PropertyOperator = PropertyMatchType | 'gt' | 'lt'

export type PropertyFilters = Record<
  string,
  {
    values: string[]
    operator: PropertyOperator
  }
>

export interface SurveyEventWithFilters {
  name: string
  propertyFilters?: PropertyFilters
}

export const SurveySchedule = {
  Once: 'once',
  Recurring: 'recurring',
  Always: 'always',
} as const
export type SurveySchedule = (typeof SurveySchedule)[keyof typeof SurveySchedule]

export type SurveyElement = {
  text?: string
  $el_text?: string
  tag_name?: string
  href?: string
  attr_id?: string
  attr_class?: string[]
  nth_child?: number
  nth_of_type?: number
  attributes?: Record<string, any>
  event_id?: number
  order?: number
  group_id?: number
}
export type SurveyRenderReason = {
  visible: boolean
  disabledReason?: string
}

export type Survey = {
  // Sync this with the backend's SurveyAPISerializer!
  id: string
  name: string
  description?: string
  type: SurveyType
  translations?: Record<string, SurveyTranslation>
  feature_flag_keys?: {
    key: string
    value?: string
  }[]
  linked_flag_key?: string
  targeting_flag_key?: string
  internal_targeting_flag_key?: string
  questions: SurveyQuestion[]
  appearance?: SurveyAppearance
  conditions?: {
    url?: string
    selector?: string
    seenSurveyWaitPeriodInDays?: number
    urlMatchType?: SurveyMatchType
    events?: {
      repeatedActivation?: boolean
      values?: SurveyEventWithFilters[]
    }
    actions?: {
      values: SurveyActionType[]
    }
    deviceTypes?: string[]
    deviceTypesMatchType?: SurveyMatchType
    linkedFlagVariant?: string
  }
  start_date?: string
  end_date?: string
  current_iteration?: number | null
  current_iteration_start_date?: string | null
  schedule?: SurveySchedule | null
  enable_partial_responses?: boolean | null
}

export type SurveyActionType = {
  id: number
  name?: string
  steps?: ActionStepType[]
}

/** Sync with plugin-server/src/types.ts */
export const ActionStepStringMatching = {
  Contains: 'contains',
  Exact: 'exact',
  Regex: 'regex',
} as const
export type ActionStepStringMatching = (typeof ActionStepStringMatching)[keyof typeof ActionStepStringMatching]

export type ActionStepType = {
  event?: string
  selector?: string
  text?: string
  /** @default StringMatching.Exact */
  text_matching?: ActionStepStringMatching
  href?: string
  /** @default ActionStepStringMatching.Exact */
  href_matching?: ActionStepStringMatching
  url?: string
  /** @default StringMatching.Contains */
  url_matching?: ActionStepStringMatching
}

export type Logger = {
  debug: (...args: any[]) => void
  info: (...args: any[]) => void
  warn: (...args: any[]) => void
  error: (...args: any[]) => void
  critical: (...args: any[]) => void
  createLogger: (prefix: string) => Logger
}

export const knownUnsafeEditableEvent = [
  '$snapshot',
  '$pageview',
  '$pageleave',
  '$set',
  'survey dismissed',
  'survey sent',
  'survey shown',
  '$identify',
  '$groupidentify',
  '$create_alias',
  '$$client_ingestion_warning',
  '$web_experiment_applied',
  '$feature_enrollment_update',
  '$feature_flag_called',
] as const

/**
 * These events can be processed by the `beforeCapture` function
 * but can cause unexpected confusion in data.
 *
 * Some features of PostHog rely on receiving 100% of these events
 */
export type KnownUnsafeEditableEvent = (typeof knownUnsafeEditableEvent)[number]

export const knownUnsafeEditableEventProperty = ['token'] as const

/**
 * These event properties can be edited by the `before_send` function
 * but are required for the event to be ingested. For example `token` carries
 * the project api_key, and ingest rejects any event that arrives without it.
 *
 * If a `before_send` function removes one of these, the event is dropped.
 */
export type KnownUnsafeEditableEventProperty = (typeof knownUnsafeEditableEventProperty)[number]

/**
 * Represents an event before it's sent to PostHog.
 * This is the interface exposed to the `before_send` hook, matching the web SDK's `CaptureResult`.
 */
export type CaptureEvent = {
  /** UUID for the event (optional to allow compatibility with Node SDK's EventMessage). Must be a valid UUID. */
  uuid?: string
  /** The name of the event */
  event: string
  /** Properties associated with the event (optional to allow compatibility with Node SDK's EventMessage) */
  properties?: PostHogEventProperties
  /** Properties to set on the person (overrides existing values) */
  $set?: PostHogEventProperties
  /** Properties to set on the person only once (does not override existing values) */
  $set_once?: PostHogEventProperties
  /** Timestamp for the event */
  timestamp?: Date
}

/**
 * Function type for the `before_send` hook.
 * Receives an event and can return a modified event or null to drop the event.
 */
export type BeforeSendFn = (event: CaptureEvent) => CaptureEvent | null
