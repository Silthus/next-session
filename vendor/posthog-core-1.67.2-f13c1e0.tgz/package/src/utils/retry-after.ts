/**
 * Longest `Retry-After` the SDK will wait. A rate-limit window can legitimately
 * be long, but nothing upstream of the SDK bounds this header — it is as likely
 * to come from a proxy or CDN as from PostHog — and an unbounded value would
 * strand a queue for hours, so the wait is capped and the retry happens early.
 */
export const MAX_RETRY_AFTER_MS = 5 * 60_000

/**
 * How far the wall clock may run behind the moment a window was installed before
 * the window is discarded. NTP corrections on a healthy host are milliseconds,
 * so a step past this is a clock change the deadline can no longer measure.
 */
const CLOCK_STEP_TOLERANCE_MS = 5_000

/**
 * `Retry-After` as milliseconds from now. The header is either delta-seconds or
 * an HTTP-date; anything else, a date already in the past, or a non-positive
 * delta yields `undefined` so the caller keeps its own backoff. The result is
 * capped at `maxMs`, which defaults to `MAX_RETRY_AFTER_MS`.
 */
export function parseRetryAfterMs(
  value: unknown,
  now: number = Date.now(),
  maxMs: number = MAX_RETRY_AFTER_MS
): number | undefined {
  if (typeof value !== 'string' || !value) {
    return undefined
  }
  const raw = value.trim()
  // `headers.get` joins repeated headers with ", ", so a CDN and a load
  // balancer that each append one yield "60, 120". Read the first, which the
  // outermost hop set — but only for delta-seconds, since an HTTP-date carries
  // a comma of its own ("Wed, 21 Oct 2015 07:28:00 GMT").
  const trimmed = /^\d+\s*,/.test(raw) ? raw.slice(0, raw.indexOf(',')).trim() : raw
  // Integer seconds. Not parseFloat: "10 minutes" must not read as 10 seconds.
  if (/^\d+$/.test(trimmed)) {
    // Cap before multiplication: even a valid integer can overflow to Infinity.
    const ms = Math.min(Number(trimmed), maxMs / 1000) * 1000
    return ms > 0 ? ms : undefined
  }
  // HTTP dates start with a weekday. Do not let Date.parse guess a date from
  // malformed seconds, ISO timestamps or month-first dates.
  if (!/^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)[a-z]*[ ,]/.test(trimmed)) {
    return undefined
  }
  // The obsolete asctime HTTP-date omits the timezone, but is still GMT.
  const date = /^\w{3} \w{3} /.test(trimmed) ? trimmed + ' GMT' : trimmed
  const ms = Date.parse(date) - now
  if (!Number.isFinite(ms) || ms <= 0) {
    return undefined
  }
  return Math.min(ms, maxMs)
}

/** The part of an export outcome the window reads. */
export type RetryAfterOutcome = {
  kind: 'ok' | 'retry-later' | 'too-large' | 'fatal'
  retryAfterMs?: number
}

/**
 * The wait an ingestion endpoint asked for, shared by the logs, metrics and
 * traces export queues.
 *
 * Held as an absolute deadline rather than a duration, so a timer armed while
 * the wait is already part-served counts down the remainder instead of
 * restarting it.
 */
export class RetryAfterWindow {
  private _until = 0
  private _installedAt = 0

  /**
   * Folds one export outcome into the window.
   *
   * A refusal naming a longer wait than the one being served pushes the
   * deadline out, but never past `MAX_RETRY_AFTER_MS` from where the window was
   * first installed. That ceiling is the SDK's own policy rather than OTLP's,
   * which asks for the header to be honoured and names no cap: a host flushing
   * faster than the window is long would otherwise refresh the deadline forever
   * and never recover, since logs gates its size trigger and `onReconnect` on
   * the window and metrics re-arms its timer from it. The cost is that a wait
   * longer than the ceiling is served short.
   *
   * The deadline is never pulled in, so a shorter header cannot cut a wait the
   * endpoint already asked for.
   */
  record(outcome: RetryAfterOutcome): void {
    if (outcome.kind === 'too-large') {
      // A verdict on the body's size, whether the SDK's own or the endpoint's
      // 413, and either way silent on the endpoint's rate limit.
      return
    }
    if (outcome.kind !== 'retry-later') {
      // A stale deadline left set here would pin every later send at a window
      // the endpoint has moved on from.
      this.reset()
      return
    }
    if (!outcome.retryAfterMs) {
      // A refusal that names no wait — a network error, a timeout, a
      // header-less 503 — does not revoke one the endpoint already named.
      return
    }
    // Read before `_installedAt` is used: a spent window resets it, and a
    // backward clock step is caught here rather than extending off a stale one.
    const open = this.isOpen()
    const now = Date.now()
    const asked = Math.min(outcome.retryAfterMs, MAX_RETRY_AFTER_MS)
    if (!open) {
      this._installedAt = now
      this._until = now + asked
      return
    }
    this._until = Math.max(this._until, Math.min(now + asked, this._installedAt + MAX_RETRY_AFTER_MS))
  }

  /**
   * Milliseconds left of the wait, `0` when none is open. Closes a window it
   * finds spent, so a later backward clock step cannot bring it back.
   */
  remainingMs(): number {
    const now = Date.now()
    if (now < this._installedAt - CLOCK_STEP_TOLERANCE_MS) {
      this.reset()
      return 0
    }
    const remaining = Math.min(MAX_RETRY_AFTER_MS, Math.max(0, this._until - now))
    if (remaining === 0) {
      this.reset()
    }
    return remaining
  }

  isOpen(): boolean {
    return this.remainingMs() > 0
  }

  reset(): void {
    this._until = 0
    this._installedAt = 0
  }
}
