import type { LogAttributeValue } from '@posthog/types'
import { buildOtlpLogRecord, buildOtlpLogsPayload, buildResourceAttributes } from './logs-utils'
import { Logger, PostHogPersistedProperty } from '../types'
import { isArray, raceWithTimeout } from '../utils'
import { FlushTimer } from '../utils/flush-timer'
import { RetryAfterWindow } from '../utils/retry-after'
import { MAX_FLUSH_BACKOFF_MS, NO_JITTER, backoffDelayMs, drawJitter } from '../utils/backoff'
import type { BufferedLogEntry, CaptureLogOptions, LogSdkContext, LogsHost, ResolvedPostHogLogsConfig } from './types'

// Caps the retry backoff at 2^6 = 64× the flush interval.

export class PostHogLogs {
  private _maxBufferSize: number
  // Eviction cap; `_maxBufferSize` only triggers a flush. Collapses to
  // `_maxBufferSize` when the host sets no separate value.
  private _maxQueueSize: number
  private _flushIntervalMs: number
  // Mutable — halved on 413 to shrink the next POST, and ramped back up by
  // one record after each successful send so a one-off oversized payload
  // (e.g. a giant stack trace) doesn't permanently degrade throughput.
  private _maxBatchRecordsPerPost: number
  private readonly _flushTimer = new FlushTimer(() => this._flushInBackground())
  // Serializes concurrent flushes — the second caller awaits the first rather
  // than racing it and double-sending the same head-of-queue records.
  private _flushPromise: Promise<void> | null = null
  // Head records evicted (FIFO) while a batch is in flight; the queue-advance
  // subtracts these so it drops the sent records, not ones captured mid-send.
  private _evictedSinceAdvance = 0
  // A batch captures this when it is assembled, so it can tell that the records it is
  // holding no longer correspond to anything queued.
  private _queueGeneration = 0
  // The `flushInBackground()` wrapper for the flush in flight, shared so overlapping
  // callers count and log one failed POST once rather than once per caller.
  private _backgroundFlushPromise: Promise<void> | null = null
  // Every path that can start a send checks this, not just the retry timer.
  private _retryAfter = new RetryAfterWindow()
  // Consecutive failed flushes; drives exponential backoff on the retry timer.
  // A successful flush resets it to 0.
  private _consecutiveFlushFailures = 0
  private _flushJitter = NO_JITTER

  // Fixed-window rate cap. Tumbling (not sliding) for cheap arithmetic on the
  // hot path. Window rolls the first time `captureLog` fires after the window
  // expires — no background timer needed. `_droppedWarned` keeps the log noise
  // to one line per window regardless of how many records got dropped.
  private _rateCapWindowMs: number
  private _maxLogsPerInterval?: number
  private _intervalWindowStart = 0
  private _intervalLogCount = 0
  private _droppedWarned = false

  constructor(
    private readonly _instance: LogsHost,
    private readonly _config: ResolvedPostHogLogsConfig,
    private readonly _logger: Logger,
    private readonly _getContext: () => LogSdkContext,
    private readonly _onReady: (fn: () => void) => void,
    // Waits for the logs-storage persist to hit disk. Called between batches
    // so a crash after a successful HTTP send but before the queue-advance
    // reaches disk can't cause duplicate records on next startup. SDKs with
    // synchronous storage (or no async persist layer) can pass a no-op. RN
    // wires this to its dedicated `_logsStorage.waitForPersist()`.
    private readonly _waitForStoragePersist: () => Promise<void> = () => Promise.resolve(),
    // OTLP instrumentation scope name. Overrides the `getLibraryId()` fallback
    // so a host can label a specific capture stream (e.g. 'console' for browser
    // console auto-capture). Defaults to `getLibraryId()` when omitted.
    private readonly _scopeName?: string,
    // True once the user has withdrawn consent. Checked before every flush iteration so
    // queued records are dropped rather than exported, by a timer or a drain under way.
    // Opt-in: a browser host's `optedOut` also reads true while it shuts down, when the
    // final flush must still go out, so only a host that separates the two passes this.
    private readonly _isConsentWithdrawn: () => boolean = () => false
  ) {
    this._maxBufferSize = _config.maxBufferSize
    // Never below the flush trigger: a smaller eviction cap would stop the
    // size-based flush from ever firing. Collapses to `maxBufferSize` when unset.
    this._maxQueueSize = Math.max(_config.maxQueueSize ?? _config.maxBufferSize, _config.maxBufferSize)
    this._flushIntervalMs = _config.flushIntervalMs
    this._maxBatchRecordsPerPost = _config.maxBatchRecordsPerPost
    this._rateCapWindowMs = _config.rateCapWindowMs
    this._maxLogsPerInterval = _config.maxLogsPerInterval
  }

  /**
   * Drops every queued record. A batch this instance has in flight is retired with
   * them, so it can neither re-send what was just purged nor advance past records
   * captured after this call.
   */
  clearQueue(): void {
    this._queueGeneration++
    this._instance.setPersistedProperty(PostHogPersistedProperty.LogsQueue, [])
  }

  /** True while the endpoint's `Retry-After` window is open, so a host's automatic flush can skip logs. */
  get throttled(): boolean {
    return this._retryAfter.isOpen()
  }

  /**
   * Clears the flush timer and rate-cap state. The host owns the record queue
   * and clears it separately (the browser empties its in-memory store).
   */
  reset(): void {
    this._flushTimer.clear()
    // `_flushPromise` is deliberately left alone: clearing it would let a second flush
    // run alongside the in-flight one. Retiring that flush is `clearQueue`'s job,
    // because the queue it holds belongs to the host, not to this state.
    this._intervalWindowStart = 0
    this._intervalLogCount = 0
    this._droppedWarned = false
    this._consecutiveFlushFailures = 0
    this._flushJitter = NO_JITTER
    this._retryAfter.reset()
    this._maxBatchRecordsPerPost = this._config.maxBatchRecordsPerPost
  }

  // Call when connectivity is restored: clear the failure backoff and flush now,
  // so records don't wait out a (possibly minutes-long) backoff delay after the
  // network returns. The host owns connectivity detection (web: `online` event).
  // A `Retry-After` window survives this: the network coming back says nothing
  // about the rate limit the endpoint set, and browsers fire `online` on every
  // network handover.
  onReconnect(): void {
    this._consecutiveFlushFailures = 0
    this._flushJitter = NO_JITTER
    if (this._retryAfter.isOpen()) {
      // The wait outlives the reconnect, but something still has to schedule
      // the retry: an explicit `flush()` leaves no timer behind.
      if (this._hasQueuedRecords()) {
        this._armFlushTimer()
      }
      return
    }
    this._flushInBackground()
  }

  /**
   * Captures one log record.
   *
   * @param capturedAt State snapshotted when the event occurred, for a caller that
   * observes an event earlier than it can build the record. Defaults to the identity,
   * session and flags as of now.
   */
  captureLog(options: CaptureLogOptions, capturedAt?: { context?: LogSdkContext; occurredAtMs?: number }): void {
    if (this._instance.isDisabled) {
      return
    }
    if (this._instance.optedOut) {
      return
    }
    if (!options?.body) {
      return
    }

    // Ordering: beforeSend → rate cap → OTLP build. beforeSend runs first so
    // user-dropped records don't consume the per-interval budget.
    const filtered = this._runBeforeSend(options)
    if (filtered === null) {
      return
    }
    // beforeSend could return a record with empty body — drop it, mirroring the
    // null-return path so both beforeSend drops surface the same diagnostic.
    if (!filtered.body) {
      this._logger.info(`Log was rejected in beforeSend function`)
      return
    }

    if (!this._checkRateLimit()) {
      return
    }

    // Build before deferring so attributes reflect state at capture time, not
    // at drain time (identity/session changes between capture and drain must
    // not corrupt recorded attributes).
    const record = buildOtlpLogRecord(
      filtered,
      capturedAt?.context ?? this._getContext(),
      this._logger,
      capturedAt?.occurredAtMs
    )
    const entry: BufferedLogEntry = { record }

    this._onReady(() => this._enqueue(entry))
  }

  /**
   * Runs the configured `beforeSend` hook(s) on a capture record:
   *   - single fn OR array of fns (chain, left-to-right)
   *   - returning `null` drops the record (logged at info)
   *   - a thrown error is logged and the record is dropped
   */
  private _runBeforeSend(options: CaptureLogOptions): CaptureLogOptions | null {
    const beforeSend = this._config.beforeSend
    if (!beforeSend) {
      return options
    }
    const fns = isArray(beforeSend) ? beforeSend : [beforeSend]
    let result: CaptureLogOptions = options
    for (const fn of fns) {
      try {
        const next = fn(result)
        if (!next) {
          this._logger.info(`Log was rejected in beforeSend function`)
          return null
        }
        result = next
      } catch (e) {
        this._logger.error(`Error in beforeSend function for log:`, e)
        return null
      }
    }
    return result
  }

  /**
   * Returns `true` if this capture fits within the current rate-cap window,
   * `false` if it should be dropped.
   *
   * Fixed (tumbling) window: the counter resets the first time `captureLog`
   * fires after `rateCapWindowMs` has elapsed — no timer needed.
   * `maxLogsPerInterval === undefined` means unbounded.
   *
   * Wall-clock safety: if `Date.now()` jumps backward (manual device-clock
   * change, big NTP correction), `elapsed` goes negative. We treat that the
   * same as "window expired" and reset — otherwise the rate cap would be
   * stuck until the clock caught up to the old window start, potentially
   * dropping logs for hours.
   *
   * Pre-init note: the counter increments here, before `_onReady` defers
   * `_enqueue` to the init promise. If init resolves slowly and the user is
   * later opted out, the counter has already consumed budget for records
   * that won't enqueue. Cosmetic — no record is "lost" beyond what's
   * already gated, and the window rolls on its own.
   */
  private _checkRateLimit(): boolean {
    if (this._maxLogsPerInterval === undefined) {
      return true
    }
    const now = Date.now()
    const elapsed = now - this._intervalWindowStart
    if (elapsed >= this._rateCapWindowMs || elapsed < 0) {
      this._intervalWindowStart = now
      this._intervalLogCount = 0
      this._droppedWarned = false
    }
    if (this._intervalLogCount >= this._maxLogsPerInterval) {
      if (!this._droppedWarned) {
        this._logger.warn(
          `captureLog dropping logs: exceeded ${this._maxLogsPerInterval} logs per ${this._rateCapWindowMs}ms`
        )
        this._droppedWarned = true
      }
      return false
    }
    this._intervalLogCount++
    return true
  }

  /**
   * Drains `LogsQueue` in `maxBatchRecordsPerPost` slices, POSTing each as an
   * OTLP payload.
   *   - Network error   → keep items in queue, re-throw (caller retries later)
   *   - 413             → halve batch size, retry same records (do not advance)
   *   - Any other error → drop the batch (avoid infinite loop on malformed data),
   *                       re-throw so callers can log/report
   * Concurrent calls are serialized through `_flushPromise` so records at the
   * head of the queue can't be sent twice.
   */
  async flush(): Promise<void> {
    if (this._instance.isDisabled) {
      return
    }
    if (this._flushPromise) {
      return this._flushPromise
    }
    this._flushPromise = this._flushInner().finally(() => {
      this._flushPromise = null
    })
    return this._flushPromise
  }

  private async _flushInner(): Promise<void> {
    this._flushTimer.clear()

    if (this._discardQueueIfConsentWithdrawn()) {
      return
    }
    let queue = this._instance.getPersistedProperty<BufferedLogEntry[]>(PostHogPersistedProperty.LogsQueue) ?? []
    if (queue.length === 0) {
      return
    }

    const originalQueueLength = queue.length
    let sentCount = 0

    while (queue.length > 0 && sentCount < originalQueueLength) {
      // Re-checked on every iteration, including a 413 shrink-and-retry that sends no
      // progress: a send suspends, so the user can opt out while one is in flight.
      if (this._discardQueueIfConsentWithdrawn()) {
        return
      }
      // Captured per batch, not per flush: a clear that lands between batches leaves
      // the next one assembled from an already-fresh queue, so that batch advances
      // normally instead of being retired for a purge it never held.
      const generation = this._queueGeneration
      // Reset per batch so the advance below counts only evictions during THIS
      // batch's send. Evictions during the persist await or between iterations
      // are already reflected in the next iteration's queue read, so they must
      // not carry into the next batch's drop math.
      this._evictedSinceAdvance = 0

      const batchSize = Math.min(queue.length, this._maxBatchRecordsPerPost)
      const batch = queue.slice(0, batchSize)
      const records = batch.map((e) => e.record)

      const payload = buildOtlpLogsPayload(
        records,
        this._buildResourceAttributes(),
        this._scopeName ?? this._instance.getLibraryId(),
        this._instance.getLibraryVersion()
      )

      const outcome = await this._instance._sendLogsBatch(payload)

      if (this._queueGeneration !== generation) {
        // The queue was cleared while this batch was in flight. `queue` is a stale local
        // copy, so retrying it would re-send purged records and advancing it would slice
        // records captured since. Retire the batch instead.
        return
      }

      if (outcome.kind === 'too-large' && batch.length > 1) {
        this._maxBatchRecordsPerPost = Math.max(1, Math.floor(batch.length / 2))
        this._logger.warn(
          `Logs batch of size ${batch.length} was too large for the ingestion endpoint, reducing batch size to ${this._maxBatchRecordsPerPost}`
        )
        // Don't advance the queue — retry the same records with the smaller cap.
        continue
      }

      // Not on the background wrapper: every lifecycle hook takes `flush()`,
      // which does not go through it.
      this._retryAfter.record(outcome)

      // Outright, not through the ratchet: a timer a mid-flight capture armed
      // is measured against a window this outcome may just have closed.
      if (this._flushTimer.pending) {
        this._flushTimer.arm(Math.max(this._flushIntervalMs, this._retryAfter.remainingMs()))
      }

      if (outcome.kind === 'retry-later') {
        // Transient failure: keep records in the queue for the next flush cycle
        // and surface the error so the caller can log/react.
        throw outcome.error
      }

      // ok | fatal | too-large-with-batch-of-1 → records are leaving the
      // queue. 'fatal' and size-1 refusals are dropped so we don't spin on the
      // same record forever. Surface the size-1 refusal explicitly so a single
      // oversized record (e.g. a giant body field) is visible in logs
      // instead of silently disappearing.
      if (outcome.kind === 'too-large') {
        // Reached either from a 413 or from the size the SDK measured before
        // sending, so the message names neither.
        this._logger.warn(
          'Dropping a single log record with batch size 1 — the record is larger than the server cap and cannot be split further.'
        )
      } else if (outcome.kind === 'ok' && this._maxBatchRecordsPerPost < this._config.maxBatchRecordsPerPost) {
        // Linear recovery: each healthy send pushes the cap back up by 1
        // toward the configured maximum. Linear (not doubling) so we don't
        // immediately retrigger a 413 if the previous shrink was justified.
        this._maxBatchRecordsPerPost = Math.min(this._config.maxBatchRecordsPerPost, this._maxBatchRecordsPerPost + 1)
      }
      await this._persistQueueAdvance(batch.length)
      queue = this._instance.getPersistedProperty<BufferedLogEntry[]>(PostHogPersistedProperty.LogsQueue) ?? []
      sentCount += batch.length

      if (outcome.kind === 'fatal') {
        throw outcome.error
      }
    }
  }

  /**
   * Drops the queue once consent is withdrawn. Records carry the distinct id and
   * session id, so whatever is still queued when the user opts out must not be
   * exported, by a pending timer or by a drain already under way.
   */
  private _discardQueueIfConsentWithdrawn(): boolean {
    if (!this._isConsentWithdrawn()) {
      return false
    }
    if (this._hasQueuedRecords()) {
      this.clearQueue()
    }
    return true
  }

  private async _persistQueueAdvance(consumed: number): Promise<void> {
    // Re-read in case captures landed mid-flush. Subtract head records the FIFO cap
    // evicted during the send (already-sent records that left the queue), so we drop
    // only the still-present sent records, not ones captured during the send.
    const evicted = this._evictedSinceAdvance
    const drop = Math.max(0, consumed - evicted)
    const refreshed = this._instance.getPersistedProperty<BufferedLogEntry[]>(PostHogPersistedProperty.LogsQueue) ?? []
    this._instance.setPersistedProperty(PostHogPersistedProperty.LogsQueue, refreshed.slice(drop))
    // Persist before the next batch sends so a crash after HTTP success can't dupe.
    await this._waitForStoragePersist()
  }

  private _buildResourceAttributes(): Record<string, LogAttributeValue> {
    return buildResourceAttributes(this._config, this._instance.getLibraryId(), this._instance.getLibraryVersion())
  }

  private _enqueue(entry: BufferedLogEntry): void {
    // Re-check optedOut: preload may have hydrated the real persisted value,
    // or optIn/optOut may have fired while this fn was deferred.
    if (this._instance.optedOut) {
      return
    }

    const queue = this._instance.getPersistedProperty<BufferedLogEntry[]>(PostHogPersistedProperty.LogsQueue) ?? []
    // Drop the oldest only above the eviction cap, not at the flush trigger, so a
    // burst is held while the async flush drains.
    if (queue.length >= this._maxQueueSize) {
      queue.shift()
      this._evictedSinceAdvance++
      this._logger.info('Logs queue is full, dropping oldest record.')
    }
    queue.push(entry)
    this._instance.setPersistedProperty(PostHogPersistedProperty.LogsQueue, queue)

    // Flush trigger: drain now rather than waiting for the timer. The queue may
    // grow past this up to the eviction cap while the flush is in flight. Not
    // while the endpoint has asked us to wait: the size trigger is the dominant
    // one on a busy host, so sending here would ignore the window entirely.
    if (queue.length >= this._maxBufferSize && !this._retryAfter.isOpen()) {
      this._flushInBackground()
      return
    }

    // Arm one timer at a time; re-arming on every enqueue would push the flush out.
    this._armFlushTimer()
  }

  // Arms the flush timer if none is pending. One-shot: the callback clears the
  // handle so the next enqueue (or a flush that left records) schedules again.
  private _armFlushTimer(): void {
    if (this._flushTimer.pending) {
      return
    }
    // Floored by any open window: `flush()` leaves no timer behind, so a
    // capture after one arrives here.
    this._flushTimer.arm(Math.max(this._flushIntervalMs, this._retryAfter.remainingMs()))
  }

  // Retry delay after a flush that left records: the first retry is at the base
  // interval, then exponential backoff so a sustained outage isn't retried every
  // interval. Jitter is drawn once per failure and reused, so two delays taken
  // for the same failure cannot disagree.
  private _nextFlushDelay(): number {
    // A floor, not a replacement: the header never retries us sooner than our
    // own backoff would have.
    return Math.max(
      backoffDelayMs(this._flushIntervalMs, this._consecutiveFlushFailures, this._flushJitter, MAX_FLUSH_BACKOFF_MS),
      this._retryAfter.remainingMs()
    )
  }

  private _hasQueuedRecords(): boolean {
    const queue = this._instance.getPersistedProperty<BufferedLogEntry[]>(PostHogPersistedProperty.LogsQueue)
    return !!queue && queue.length > 0
  }

  /**
   * Stops the timer-based flush and sends anything still in the queue.
   * Intended for process-teardown paths (RN `_shutdown` override). Swallows
   * errors so a failing final flush can't block the broader shutdown.
   *
   * If `timeoutMs` is provided, the final flush races against that budget so
   * a slow network/storage can't hold up shutdown indefinitely. Without it,
   * flush time is bounded only by `fetchRetryCount * (requestTimeout +
   * fetchRetryDelay)`, which can exceed the caller's shutdown SLA.
   */
  async shutdown(timeoutMs?: number): Promise<void> {
    this._flushTimer.clear()
    const flushPromise = this.flush().catch(() => {
      // Best-effort: a logs-flush failure during shutdown is not actionable
      // and must not prevent the rest of shutdown from running. Errors are
      // still surfaced from the regular `flush()` path in normal operation.
    })
    if (timeoutMs === undefined) {
      await flushPromise
      return
    }
    await raceWithTimeout(flushPromise, timeoutMs)
  }

  /**
   * Time-bounded flush for transient lifecycle events (e.g. RN
   * foreground→background) that must complete inside an OS-imposed window.
   * Unlike `shutdown`, this leaves the periodic flush timer in place so the
   * pipeline keeps draining if the process is resumed instead of suspended.
   *
   * Errors propagate so the host SDK can route them through its standard
   * lifecycle error handler (e.g. RN's `logFlushError`). If the timer wins
   * the race, a late rejection from the in-flight flush is silenced via a
   * no-op handler attached after the race settles, to avoid noisy
   * unhandled-rejection logs — the next regular flush cycle will retry.
   */
  async flushWithTimeout(timeoutMs: number): Promise<void> {
    const flushPromise = this.flush()
    await raceWithTimeout(flushPromise, timeoutMs, () => {
      // Race lost — flush is still in flight. Attach a no-op rejection
      // handler so a late failure isn't logged as unhandled.
      void flushPromise.catch(() => {})
    })
  }

  /**
   * `flush()` for a host that drives logs from its own flush cycle. Never rejects, and when
   * records remain (a failed send, or captures that landed mid-flush) re-arms the timer with
   * backoff, as the pipeline's own timer flush does. A bare `flush()` clears the timer and
   * leaves nothing to retry the records once traffic stops.
   */
  flushInBackground(): Promise<void> {
    if (this._backgroundFlushPromise) {
      return this._backgroundFlushPromise
    }
    const promise = this.flush()
      .then(
        () => {
          this._consecutiveFlushFailures = 0
          this._flushJitter = NO_JITTER
        },
        (err) => {
          this._consecutiveFlushFailures++
          this._flushJitter = drawJitter()
          this._logger.error('PostHog logs flush failed:', err)
        }
      )
      .finally(() => {
        // Records remaining (transient failure or mid-flush captures) would otherwise
        // sit undelivered on a quiet page; re-arm so the timer retries them, backing
        // off on consecutive failures.
        if (this._backgroundFlushPromise === promise) {
          this._backgroundFlushPromise = null
        }
        if (!this._instance.isDisabled && this._hasQueuedRecords()) {
          this._flushTimer.armNoEarlierThan(this._nextFlushDelay())
        }
      })
    this._backgroundFlushPromise = promise
    return promise
  }

  private _flushInBackground(): void {
    void this.flushInBackground()
  }
}
