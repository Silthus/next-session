import { PostHogCore } from '@/posthog-core'
import type { GetFlagsResult, JsonType, PostHogCoreOptions, PostHogFetchOptions, PostHogFetchResponse } from '@/types'

const version = '2.0.0-alpha'

export interface PostHogCoreTestClientMocks {
  fetch: vi.Mock<Promise<PostHogFetchResponse>, [string, PostHogFetchOptions]>
  storage: {
    getItem: vi.Mock<any | undefined, [string]>
    setItem: vi.Mock<void, [string, any | null]>
  }
}

export class PostHogCoreTestClient extends PostHogCore {
  public _cachedDistinctId?: string

  constructor(
    private mocks: PostHogCoreTestClientMocks,
    projectToken: string,
    options?: PostHogCoreOptions
  ) {
    super(projectToken, options)

    this.setupBootstrap(options)
  }

  // Expose protected methods for testing
  public getFlags(
    distinctId: string,
    groups: Record<string, string | number> = {},
    personProperties: Record<string, string> = {},
    groupProperties: Record<string, Record<string, string>> = {},
    extraPayload: Record<string, any> = {}
  ): Promise<GetFlagsResult> {
    return super.getFlags(distinctId, groups, personProperties, groupProperties, extraPayload)
  }

  public flushWithPendingPromises(): Promise<void> {
    return super.flushWithPendingPromises()
  }

  getPersistedProperty<T>(key: string): T {
    return this.mocks.storage.getItem(key)
  }
  setPersistedProperty<T>(key: string, value: T | null): void {
    return this.mocks.storage.setItem(key, value)
  }
  fetch(url: string, options: PostHogFetchOptions): Promise<PostHogFetchResponse> {
    return this.mocks.fetch(url, options)
  }
  getLibraryId(): string {
    return 'posthog-core-tests'
  }
  getLibraryVersion(): string {
    return version
  }
  getCustomUserAgent(): string {
    return 'posthog-core-tests'
  }
}

export const createTestClient = (
  projectToken: string,
  options?: PostHogCoreOptions,
  setupMocks?: (mocks: PostHogCoreTestClientMocks) => void,
  storageCache: { [key: string]: string | JsonType } = {}
): [PostHogCoreTestClient, PostHogCoreTestClientMocks] => {
  const mocks = {
    fetch: vi.fn(),
    storage: {
      getItem: vi.fn((key) => storageCache[key]),
      setItem: vi.fn((key, val) => {
        storageCache[key] = val == null ? undefined : val
      }),
    },
  }

  mocks.fetch.mockImplementation(() =>
    Promise.resolve({
      status: 200,
      text: () => Promise.resolve('ok'),
      json: () => Promise.resolve({ status: 'ok' }),
    })
  )

  setupMocks?.(mocks)

  return [new PostHogCoreTestClient(mocks, projectToken, { disableCompression: true, ...options }), mocks]
}
